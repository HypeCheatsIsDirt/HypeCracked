﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace cw
{
	// Token: 0x0200000B RID: 11
	internal class cwapi
	{
		// Token: 0x060000B6 RID: 182
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr OpenProcess(cwapi.ProcessAccessFlags processAccess, bool bInheritHandle, int processId);

		// Token: 0x060000B7 RID: 183
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, long nSize, out IntPtr lpNumberOfBytesRead);

		// Token: 0x060000B8 RID: 184
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, [MarshalAs(UnmanagedType.AsAny)] object lpBuffer, long nSize, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x060000B9 RID: 185
		[DllImport("kernel32.dll")]
		private static extern bool Process32First(IntPtr hSnapshot, ref cwapi.PROCESSENTRY32 lppe);

		// Token: 0x060000BA RID: 186
		[DllImport("kernel32.dll")]
		private static extern bool Process32Next(IntPtr hSnapshot, ref cwapi.PROCESSENTRY32 lppe);

		// Token: 0x060000BB RID: 187
		[DllImport("kernel32.dll")]
		private static extern bool Module32First(IntPtr hSnapshot, ref cwapi.MODULEENTRY32 lpme);

		// Token: 0x060000BC RID: 188
		[DllImport("kernel32.dll")]
		private static extern bool Module32Next(IntPtr hSnapshot, ref cwapi.MODULEENTRY32 lpme);

		// Token: 0x060000BD RID: 189
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hHandle);

		// Token: 0x060000BE RID: 190
		[DllImport("user32.dll")]
		public static extern short GetAsyncKeyState(Keys vKey);

		// Token: 0x060000BF RID: 191
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern IntPtr CreateToolhelp32Snapshot(cwapi.SnapshotFlags dwFlags, int th32ProcessID);

		// Token: 0x060000C0 RID: 192 RVA: 0x0000C89C File Offset: 0x0000AA9C
		public static IntPtr GetModuleBaseAddress(Process proc, string modName)
		{
			IntPtr result = IntPtr.Zero;
			foreach (object obj in proc.Modules)
			{
				ProcessModule processModule = (ProcessModule)obj;
				bool flag = processModule.ModuleName == modName;
				bool flag2 = flag;
				if (flag2)
				{
					result = processModule.BaseAddress;
					break;
				}
			}
			return result;
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x0000C928 File Offset: 0x0000AB28
		public static IntPtr GetModuleBaseAddress(int procId, string modName)
		{
			IntPtr result = IntPtr.Zero;
			IntPtr intPtr = cwapi.CreateToolhelp32Snapshot(cwapi.SnapshotFlags.Module | cwapi.SnapshotFlags.Module32, procId);
			bool flag = intPtr.ToInt64() != -1L;
			bool flag2 = flag;
			if (flag2)
			{
				cwapi.MODULEENTRY32 moduleentry = default(cwapi.MODULEENTRY32);
				moduleentry.dwSize = (uint)Marshal.SizeOf(typeof(cwapi.MODULEENTRY32));
				bool flag3 = cwapi.Module32First(intPtr, ref moduleentry);
				bool flag4 = flag3;
				if (flag4)
				{
					for (;;)
					{
						bool flag5 = moduleentry.szModule.Equals(modName);
						bool flag6 = flag5;
						if (flag6)
						{
							break;
						}
						bool flag7 = !cwapi.Module32Next(intPtr, ref moduleentry);
						if (flag7)
						{
							goto Block_4;
						}
					}
					result = moduleentry.modBaseAddr;
					Block_4:;
				}
			}
			cwapi.CloseHandle(intPtr);
			return result;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000C9DC File Offset: 0x0000ABDC
		public static IntPtr FindDMAAddy(IntPtr hProc, IntPtr ptr, int[] offsets)
		{
			byte[] array = new byte[IntPtr.Size];
			foreach (int offset in offsets)
			{
				IntPtr intPtr;
				cwapi.ReadProcessMemory(hProc, ptr, array, (long)array.Length, out intPtr);
				ptr = ((IntPtr.Size == 4) ? IntPtr.Add(new IntPtr(BitConverter.ToInt32(array, 0)), offset) : (ptr = IntPtr.Add(new IntPtr(BitConverter.ToInt64(array, 0)), offset)));
			}
			return ptr;
		}

		// Token: 0x040000F1 RID: 241
		private const int INVALID_HANDLE_VALUE = -1;

		// Token: 0x0200000C RID: 12
		[Flags]
		public enum ProcessAccessFlags : uint
		{
			// Token: 0x040000F3 RID: 243
			All = 2035711U,
			// Token: 0x040000F4 RID: 244
			Terminate = 1U,
			// Token: 0x040000F5 RID: 245
			CreateThread = 2U,
			// Token: 0x040000F6 RID: 246
			VirtualMemoryOperation = 8U,
			// Token: 0x040000F7 RID: 247
			VirtualMemoryRead = 16U,
			// Token: 0x040000F8 RID: 248
			VirtualMemoryWrite = 32U,
			// Token: 0x040000F9 RID: 249
			DuplicateHandle = 64U,
			// Token: 0x040000FA RID: 250
			CreateProcess = 128U,
			// Token: 0x040000FB RID: 251
			SetQuota = 256U,
			// Token: 0x040000FC RID: 252
			SetInformation = 512U,
			// Token: 0x040000FD RID: 253
			QueryInformation = 1024U,
			// Token: 0x040000FE RID: 254
			QueryLimitedInformation = 4096U,
			// Token: 0x040000FF RID: 255
			Synchronize = 1048576U
		}

		// Token: 0x0200000D RID: 13
		public struct PROCESSENTRY32
		{
			// Token: 0x04000100 RID: 256
			public uint dwSize;

			// Token: 0x04000101 RID: 257
			public uint cntUsage;

			// Token: 0x04000102 RID: 258
			public uint th32ProcessID;

			// Token: 0x04000103 RID: 259
			public IntPtr th32DefaultHeapID;

			// Token: 0x04000104 RID: 260
			public uint th32ModuleID;

			// Token: 0x04000105 RID: 261
			public uint cntThreads;

			// Token: 0x04000106 RID: 262
			public uint th32ParentProcessID;

			// Token: 0x04000107 RID: 263
			public int pcPriClassBase;

			// Token: 0x04000108 RID: 264
			public uint dwFlags;

			// Token: 0x04000109 RID: 265
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			public string szExeFile;
		}

		// Token: 0x0200000E RID: 14
		public struct MODULEENTRY32
		{
			// Token: 0x0400010A RID: 266
			internal uint dwSize;

			// Token: 0x0400010B RID: 267
			internal uint th32ModuleID;

			// Token: 0x0400010C RID: 268
			internal uint th32ProcessID;

			// Token: 0x0400010D RID: 269
			internal uint GlblcntUsage;

			// Token: 0x0400010E RID: 270
			internal uint ProccntUsage;

			// Token: 0x0400010F RID: 271
			internal IntPtr modBaseAddr;

			// Token: 0x04000110 RID: 272
			internal uint modBaseSize;

			// Token: 0x04000111 RID: 273
			internal IntPtr hModule;

			// Token: 0x04000112 RID: 274
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
			internal string szModule;

			// Token: 0x04000113 RID: 275
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			internal string szExePath;
		}

		// Token: 0x0200000F RID: 15
		[Flags]
		private enum SnapshotFlags : uint
		{
			// Token: 0x04000115 RID: 277
			HeapList = 1U,
			// Token: 0x04000116 RID: 278
			Process = 2U,
			// Token: 0x04000117 RID: 279
			Thread = 4U,
			// Token: 0x04000118 RID: 280
			Module = 8U,
			// Token: 0x04000119 RID: 281
			Module32 = 16U,
			// Token: 0x0400011A RID: 282
			Inherit = 2147483648U,
			// Token: 0x0400011B RID: 283
			All = 31U,
			// Token: 0x0400011C RID: 284
			NoHeaps = 1073741824U
		}
	}
}
