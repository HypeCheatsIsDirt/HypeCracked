﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("0d913cb9-8434-42c4-84c2-9a7ce8e67de2")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyProduct("HypeTool VIP")]
[assembly: AssemblyCopyright("Copyright © HypeCheats 2021")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("HypeTool VIP")]
[assembly: AssemblyCompany("HypeCheats")]
