﻿namespace CWTuulBase
{
	// Token: 0x02000006 RID: 6
	public partial class Form3 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000090 RID: 144 RVA: 0x0000AB24 File Offset: 0x00008D24
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x0000AB5C File Offset: 0x00008D5C
		private void InitializeComponent()
		{
            this.jThinButton1 = new JThinButton.JThinButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.jFlatButton1 = new FlatButton.JFlatButton();
            this.jFlatButton2 = new FlatButton.JFlatButton();
            this.SuspendLayout();
            // 
            // jThinButton1
            // 
            this.jThinButton1.BackColor = System.Drawing.Color.Transparent;
            this.jThinButton1.BackgroundColor = System.Drawing.Color.Crimson;
            this.jThinButton1.BorderColor = System.Drawing.Color.Crimson;
            this.jThinButton1.BorderRadius = 12;
            this.jThinButton1.ButtonText = "LOAD TUUL";
            this.jThinButton1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jThinButton1.Font_Size = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jThinButton1.ForeColors = System.Drawing.Color.White;
            this.jThinButton1.HoverBackground = System.Drawing.Color.White;
            this.jThinButton1.HoverBorder = System.Drawing.Color.Empty;
            this.jThinButton1.HoverFontColor = System.Drawing.SystemColors.Highlight;
            this.jThinButton1.LineThickness = 2;
            this.jThinButton1.Location = new System.Drawing.Point(27, 131);
            this.jThinButton1.Margin = new System.Windows.Forms.Padding(4);
            this.jThinButton1.Name = "jThinButton1";
            this.jThinButton1.Size = new System.Drawing.Size(294, 93);
            this.jThinButton1.TabIndex = 0;
            this.jThinButton1.Click += new System.EventHandler(this.JThinButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(41, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 64);
            this.label1.TabIndex = 4;
            this.label1.Text = "HYPECHEATS\r\nis SHit\r\nand is a ripoff\r\nof sammys free tool\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Crimson;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "HypeTool | Auth";
            // 
            // jFlatButton1
            // 
            this.jFlatButton1.BackColor = System.Drawing.Color.Transparent;
            this.jFlatButton1.BackgroundColor = System.Drawing.Color.Transparent;
            this.jFlatButton1.ButtonText = "X";
            this.jFlatButton1.CausesValidation = false;
            this.jFlatButton1.ErrorImageLeft = null;
            this.jFlatButton1.ErrorImageRight = null;
            this.jFlatButton1.FocusBackground = System.Drawing.Color.Empty;
            this.jFlatButton1.FocusFontColor = System.Drawing.Color.Empty;
            this.jFlatButton1.ForeColors = System.Drawing.Color.White;
            this.jFlatButton1.HoverBackground = System.Drawing.Color.Empty;
            this.jFlatButton1.HoverFontColor = System.Drawing.Color.Empty;
            this.jFlatButton1.ImageLeft = null;
            this.jFlatButton1.ImageRight = null;
            this.jFlatButton1.LeftPictureColor = System.Drawing.Color.Transparent;
            this.jFlatButton1.Location = new System.Drawing.Point(287, 0);
            this.jFlatButton1.Name = "jFlatButton1";
            this.jFlatButton1.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.jFlatButton1.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.jFlatButton1.RightPictureColor = System.Drawing.Color.Transparent;
            this.jFlatButton1.Size = new System.Drawing.Size(47, 25);
            this.jFlatButton1.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.jFlatButton1.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.jFlatButton1.TabIndex = 6;
            this.jFlatButton1.Click += new System.EventHandler(this.JFlatButton1_Click);
            // 
            // jFlatButton2
            // 
            this.jFlatButton2.BackColor = System.Drawing.Color.Transparent;
            this.jFlatButton2.BackgroundColor = System.Drawing.Color.Transparent;
            this.jFlatButton2.ButtonText = "-";
            this.jFlatButton2.CausesValidation = false;
            this.jFlatButton2.ErrorImageLeft = null;
            this.jFlatButton2.ErrorImageRight = null;
            this.jFlatButton2.FocusBackground = System.Drawing.Color.Empty;
            this.jFlatButton2.FocusFontColor = System.Drawing.Color.Empty;
            this.jFlatButton2.ForeColors = System.Drawing.Color.White;
            this.jFlatButton2.HoverBackground = System.Drawing.Color.Empty;
            this.jFlatButton2.HoverFontColor = System.Drawing.Color.Empty;
            this.jFlatButton2.ImageLeft = null;
            this.jFlatButton2.ImageRight = null;
            this.jFlatButton2.LeftPictureColor = System.Drawing.Color.Transparent;
            this.jFlatButton2.Location = new System.Drawing.Point(240, 0);
            this.jFlatButton2.Name = "jFlatButton2";
            this.jFlatButton2.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.jFlatButton2.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.jFlatButton2.RightPictureColor = System.Drawing.Color.Transparent;
            this.jFlatButton2.Size = new System.Drawing.Size(47, 25);
            this.jFlatButton2.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.jFlatButton2.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.jFlatButton2.TabIndex = 7;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(39)))), ((int)(((byte)(42)))));
            this.ClientSize = new System.Drawing.Size(334, 315);
            this.Controls.Add(this.jFlatButton2);
            this.Controls.Add(this.jFlatButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jThinButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form3_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form3_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form3_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		// Token: 0x040000CF RID: 207
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x040000D0 RID: 208
		private global::JThinButton.JThinButton jThinButton1;

		// Token: 0x040000D2 RID: 210
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000D3 RID: 211
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040000D4 RID: 212
		private global::FlatButton.JFlatButton jFlatButton1;

		// Token: 0x040000D5 RID: 213
		private global::FlatButton.JFlatButton jFlatButton2;
	}
}
