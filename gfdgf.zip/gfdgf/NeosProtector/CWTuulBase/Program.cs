﻿using System;
using System.Windows.Forms;

namespace CWTuulBase
{
	// Token: 0x02000008 RID: 8
	internal static class Program
	{
		// Token: 0x0600009B RID: 155 RVA: 0x00002427 File Offset: 0x00000627
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			MessageBox.Show("Welcome to a shit tool thats skidded of sammys free tool, man didnt even take out parts of my free tool which is sad and uses a shit protector");
			Application.Run(new Form1());
		}
	}
}
