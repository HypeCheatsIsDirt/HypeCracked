﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace CWTuulBase.Properties
{
	// Token: 0x0200000A RID: 10
/*	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.8.1.0")]*/
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060000AB RID: 171 RVA: 0x0000C7F4 File Offset: 0x0000A9F4
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000AC RID: 172 RVA: 0x0000C80C File Offset: 0x0000AA0C
		// (set) Token: 0x060000AD RID: 173 RVA: 0x000024AE File Offset: 0x000006AE
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool NewUser
		{
			get
			{
				return (bool)this["NewUser"];
			}
			set
			{
				this["NewUser"] = value;
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000AE RID: 174 RVA: 0x0000C830 File Offset: 0x0000AA30
		// (set) Token: 0x060000AF RID: 175 RVA: 0x000024C3 File Offset: 0x000006C3
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string Username
		{
			get
			{
				return (string)this["Username"];
			}
			set
			{
				this["Username"] = value;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060000B0 RID: 176 RVA: 0x0000C854 File Offset: 0x0000AA54
		// (set) Token: 0x060000B1 RID: 177 RVA: 0x000024D3 File Offset: 0x000006D3
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("Your Tool Name")]
		public string AppName
		{
			get
			{
				return (string)this["AppName"];
			}
			set
			{
				this["AppName"] = value;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000B2 RID: 178 RVA: 0x0000C878 File Offset: 0x0000AA78
		// (set) Token: 0x060000B3 RID: 179 RVA: 0x000024E3 File Offset: 0x000006E3
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("CW Version: 1.9.9")]
		public string Version
		{
			get
			{
				return (string)this["Version"];
			}
			set
			{
				this["Version"] = value;
			}
		}

		// Token: 0x040000F0 RID: 240
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
