﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace CWTuulBase.Properties
{
	// Token: 0x0200000A RID: 10
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.8.1.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x17000008 RID: 8
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x0000C788 File Offset: 0x0000A988
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x0000246F File Offset: 0x0000066F
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public long PlayerBase
		{
			get
			{
				return (long)this["PlayerBase"];
			}
			set
			{
				this["PlayerBase"] = value;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x0000C7AC File Offset: 0x0000A9AC
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x00002484 File Offset: 0x00000684
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public long CMDBufferBase
		{
			get
			{
				return (long)this["CMDBufferBase"];
			}
			set
			{
				this["CMDBufferBase"] = value;
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x0000C7D0 File Offset: 0x0000A9D0
		// (set) Token: 0x060000AA RID: 170 RVA: 0x00002499 File Offset: 0x00000699
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public long XPScaleBase
		{
			get
			{
				return (long)this["XPScaleBase"];
			}
			set
			{
				this["XPScaleBase"] = value;
			}
		}
	}
}
