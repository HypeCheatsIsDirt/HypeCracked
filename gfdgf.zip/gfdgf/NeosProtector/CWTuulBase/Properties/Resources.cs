﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace CWTuulBase.Properties
{
	// Token: 0x02000009 RID: 9
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x0600009C RID: 156 RVA: 0x0000245C File Offset: 0x0000065C
		internal Resources()
		{
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600009D RID: 157 RVA: 0x0000C638 File Offset: 0x0000A838
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				bool flag2 = flag;
				if (flag2)
				{
					ResourceManager resourceManager = new ResourceManager("CWTuulBase.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600009E RID: 158 RVA: 0x0000C680 File Offset: 0x0000A880
		// (set) Token: 0x0600009F RID: 159 RVA: 0x00002466 File Offset: 0x00000666
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x060000A0 RID: 160 RVA: 0x0000C698 File Offset: 0x0000A898
		internal static Bitmap baseback
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("baseback", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x0000C6C8 File Offset: 0x0000A8C8
		internal static Bitmap hgghfhhghhgh
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("hgghfhhghhgh", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x060000A2 RID: 162 RVA: 0x0000C6F8 File Offset: 0x0000A8F8
		internal static Bitmap juiceyyy
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("juiceyyy", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x0000C728 File Offset: 0x0000A928
		internal static Bitmap purpbackkk
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("purpbackkk", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x060000A4 RID: 164 RVA: 0x0000C758 File Offset: 0x0000A958
		internal static Bitmap trippppyyy
		{
			get
			{
				object @object = Resources.ResourceManager.GetObject("trippppyyy", Resources.resourceCulture);
				return (Bitmap)@object;
			}
		}

		// Token: 0x040000EE RID: 238
		private static ResourceManager resourceMan;

		// Token: 0x040000EF RID: 239
		private static CultureInfo resourceCulture;
	}
}
