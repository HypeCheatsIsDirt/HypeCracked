﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using CWTuulBase.Properties;

namespace CWTuulBase
{
	// Token: 0x02000005 RID: 5
	public partial class Form2 : Form
	{
		// Token: 0x0600007F RID: 127 RVA: 0x00002316 File Offset: 0x00000516
		public Form2()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000080 RID: 128 RVA: 0x0000232E File Offset: 0x0000052E
		private void button1_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000081 RID: 129 RVA: 0x0000A30C File Offset: 0x0000850C
		private void button2_Click(object sender, EventArgs e)
		{
			bool flag = this.Username.Text == "" | this.toolname.Text == "";
			bool flag2 = flag;
			if (flag2)
			{
				MessageBox.Show("Don't leave anything blank");
			}
			else
			{
				MessageBox.Show("Welcome, " + this.Username.Text);
				Settings.Default.NewUser = false;
				Settings.Default.Username = this.Username.Text;
				Settings.Default.AppName = this.toolname.Text;
				Settings.Default.Save();
				new Form1().Show();
				base.Hide();
			}
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00002338 File Offset: 0x00000538
		private void MouseDown_Event(object sender, MouseEventArgs e)
		{
			this.offset.X = e.X;
			this.offset.Y = e.Y;
			this.mouseDown = true;
		}

		// Token: 0x06000083 RID: 131 RVA: 0x0000A3CC File Offset: 0x000085CC
		private void MouseMove_Event(object sender, MouseEventArgs e)
		{
			bool flag = this.mouseDown;
			bool flag2 = flag;
			if (flag2)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this.offset.X, point.Y - this.offset.Y);
			}
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00002366 File Offset: 0x00000566
		private void MouseUp_Event(object sender, MouseEventArgs e)
		{
			this.mouseDown = false;
		}

		// Token: 0x06000085 RID: 133 RVA: 0x0000205B File Offset: 0x0000025B
		private void Form2_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0000205B File Offset: 0x0000025B
		private void Username_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x040000C2 RID: 194
		private bool mouseDown;

		// Token: 0x040000C3 RID: 195
		private Point offset;
	}
}
