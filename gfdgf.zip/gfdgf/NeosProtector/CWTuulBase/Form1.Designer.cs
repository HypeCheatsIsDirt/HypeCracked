﻿namespace CWTuulBase
{
	// Token: 0x02000003 RID: 3
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600007B RID: 123 RVA: 0x000048E8 File Offset: 0x00002AE8
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			bool flag2 = flag;
			if (flag2)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00004924 File Offset: 0x00002B24
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.tuulname = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.player1 = new System.Windows.Forms.Label();
            this.p1weaponid = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label20 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.player2 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.p2weaponid = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button34 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.player3 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.p3weaponid = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button35 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.button36 = new System.Windows.Forms.Button();
            this.p4weaponid = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.player4 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button47 = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.button48 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label29 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tuulname
            // 
            this.tuulname.AutoSize = true;
            this.tuulname.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tuulname.ForeColor = System.Drawing.Color.White;
            this.tuulname.Location = new System.Drawing.Point(30, 6);
            this.tuulname.Name = "tuulname";
            this.tuulname.Size = new System.Drawing.Size(350, 74);
            this.tuulname.TabIndex = 1;
            this.tuulname.Text = "HypeTool VIP Cracked \r\nv1.6";
            this.tuulname.Click += new System.EventHandler(this.tuulname_Click);
            this.tuulname.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_Event);
            this.tuulname.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MouseMove_Event);
            this.tuulname.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MouseUp_Event);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(1126, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(1031, 614);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(146, 16);
            this.label11.TabIndex = 29;
            this.label11.Text = "CW Version: 1.10.4";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(217, 114);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 19);
            this.numericUpDown1.TabIndex = 56;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.numericUpDown1);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.button14);
            this.groupBox2.Controls.Add(this.button10);
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.button11);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.button12);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.player1);
            this.groupBox2.Controls.Add(this.p1weaponid);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.button13);
            this.groupBox2.Controls.Add(this.button16);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.button9);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(31, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(349, 280);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Player 1(Host)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(232, 97);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 18);
            this.label19.TabIndex = 47;
            this.label19.Text = "Points:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 18);
            this.label3.TabIndex = 76;
            this.label3.Text = "Weapon Swap";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.DodgerBlue;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(217, 168);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(100, 23);
            this.button14.TabIndex = 49;
            this.button14.Text = "Set Points";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DodgerBlue;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(266, 47);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(79, 26);
            this.button10.TabIndex = 45;
            this.button10.Text = "Off";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.DodgerBlue;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(217, 139);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(100, 23);
            this.button15.TabIndex = 46;
            this.button15.Text = "50K Points";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.DodgerBlue;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(180, 47);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(80, 26);
            this.button11.TabIndex = 42;
            this.button11.Text = "On";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(239, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 18);
            this.label14.TabIndex = 44;
            this.label14.Text = "(Disabled)";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DodgerBlue;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(6, 168);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(113, 23);
            this.button12.TabIndex = 51;
            this.button12.Text = "Give Gun";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(177, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 18);
            this.label15.TabIndex = 43;
            this.label15.Text = "Inf. Ammo:";
            // 
            // player1
            // 
            this.player1.AutoSize = true;
            this.player1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1.ForeColor = System.Drawing.Color.Gray;
            this.player1.Location = new System.Drawing.Point(214, 252);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(45, 16);
            this.player1.TabIndex = 55;
            this.player1.Text = "None";
            // 
            // p1weaponid
            // 
            this.p1weaponid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.p1weaponid.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p1weaponid.Location = new System.Drawing.Point(6, 117);
            this.p1weaponid.Name = "p1weaponid";
            this.p1weaponid.Size = new System.Drawing.Size(84, 16);
            this.p1weaponid.TabIndex = 50;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(163, 252);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 16);
            this.label17.TabIndex = 54;
            this.label17.Text = "Name:";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.DodgerBlue;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button13.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(6, 139);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(113, 23);
            this.button13.TabIndex = 52;
            this.button13.Text = "Weapon IDs";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.DodgerBlue;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.Red;
            this.button16.Location = new System.Drawing.Point(6, 241);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(97, 33);
            this.button16.TabIndex = 1;
            this.button16.Text = "Kick Player";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(6, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 18);
            this.label13.TabIndex = 39;
            this.label13.Text = "GodMode:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(59, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 18);
            this.label12.TabIndex = 40;
            this.label12.Text = "[Disabled]";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DodgerBlue;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(6, 47);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(80, 26);
            this.button8.TabIndex = 38;
            this.button8.Text = "On";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DodgerBlue;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(92, 47);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(80, 26);
            this.button9.TabIndex = 41;
            this.button9.Text = "Off";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(281, 611);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 16);
            this.label7.TabIndex = 25;
            this.label7.Text = "Game Status:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(411, 611);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(167, 16);
            this.label8.TabIndex = 26;
            this.label8.Text = "(Game is not running)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(1, 611);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 16);
            this.label10.TabIndex = 27;
            this.label10.Text = "HypeTool Status:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(133, 611);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 16);
            this.label9.TabIndex = 28;
            this.label9.Text = "(Off)";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(6, 95);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 18);
            this.label20.TabIndex = 57;
            this.label20.Text = "Weapon Swap";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown2.Location = new System.Drawing.Point(229, 114);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(84, 19);
            this.numericUpDown2.TabIndex = 56;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown3.Location = new System.Drawing.Point(213, 109);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(112, 19);
            this.numericUpDown3.TabIndex = 73;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown4.Location = new System.Drawing.Point(187, 110);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(84, 19);
            this.numericUpDown4.TabIndex = 73;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.button25);
            this.groupBox4.Controls.Add(this.player2);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.numericUpDown2);
            this.groupBox4.Controls.Add(this.button24);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.p2weaponid);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.button18);
            this.groupBox4.Controls.Add(this.button19);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.button21);
            this.groupBox4.Controls.Add(this.button20);
            this.groupBox4.Controls.Add(this.button23);
            this.groupBox4.Controls.Add(this.button22);
            this.groupBox4.Controls.Add(this.button17);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(31, 328);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(349, 280);
            this.groupBox4.TabIndex = 53;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Player 2";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(226, 89);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(54, 18);
            this.label23.TabIndex = 47;
            this.label23.Text = "Points:";
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.DodgerBlue;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button25.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Location = new System.Drawing.Point(6, 41);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(77, 26);
            this.button25.TabIndex = 38;
            this.button25.Text = "On";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // player2
            // 
            this.player2.AutoSize = true;
            this.player2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2.ForeColor = System.Drawing.Color.Gray;
            this.player2.Location = new System.Drawing.Point(244, 252);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(45, 16);
            this.player2.TabIndex = 55;
            this.player2.Text = "None";
            this.player2.Click += new System.EventHandler(this.player2_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(196, 252);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 16);
            this.label22.TabIndex = 54;
            this.label22.Text = "Name:";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.DodgerBlue;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button24.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(89, 41);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(79, 26);
            this.button24.TabIndex = 41;
            this.button24.Text = "Off";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // p2weaponid
            // 
            this.p2weaponid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.p2weaponid.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p2weaponid.Location = new System.Drawing.Point(6, 113);
            this.p2weaponid.Name = "p2weaponid";
            this.p2weaponid.Size = new System.Drawing.Size(84, 16);
            this.p2weaponid.TabIndex = 50;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(3, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(79, 18);
            this.label27.TabIndex = 39;
            this.label27.Text = "GodMode:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(59, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(75, 18);
            this.label26.TabIndex = 40;
            this.label26.Text = "(Disabled)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(173, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(79, 18);
            this.label25.TabIndex = 43;
            this.label25.Text = "Inf. Ammo:";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.DodgerBlue;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button18.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(6, 139);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(113, 23);
            this.button18.TabIndex = 52;
            this.button18.Text = "Weapon IDs";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.DodgerBlue;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button19.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Location = new System.Drawing.Point(6, 168);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(113, 23);
            this.button19.TabIndex = 51;
            this.button19.Text = "Give Gun";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(239, 19);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 18);
            this.label24.TabIndex = 44;
            this.label24.Text = "[Disabled]";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.DodgerBlue;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button21.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(220, 139);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(100, 23);
            this.button21.TabIndex = 46;
            this.button21.Text = "+50,000";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.DodgerBlue;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button20.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(220, 168);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(100, 23);
            this.button20.TabIndex = 49;
            this.button20.Text = "Set Points";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.DodgerBlue;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button23.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(174, 41);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(77, 26);
            this.button23.TabIndex = 42;
            this.button23.Text = "On";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.DodgerBlue;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button22.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(257, 41);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(79, 26);
            this.button22.TabIndex = 45;
            this.button22.Text = "Off";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.DodgerBlue;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.Red;
            this.button17.Location = new System.Drawing.Point(6, 241);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(99, 33);
            this.button17.TabIndex = 1;
            this.button17.Text = "Kick Player";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(59)))));
            this.groupBox5.Controls.Add(this.button30);
            this.groupBox5.Controls.Add(this.button29);
            this.groupBox5.Controls.Add(this.numericUpDown3);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.button31);
            this.groupBox5.Controls.Add(this.button32);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.button34);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.button26);
            this.groupBox5.Controls.Add(this.player3);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.button37);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.button33);
            this.groupBox5.Controls.Add(this.button27);
            this.groupBox5.Controls.Add(this.p3weaponid);
            this.groupBox5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.White;
            this.groupBox5.Location = new System.Drawing.Point(819, 45);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(349, 280);
            this.groupBox5.TabIndex = 72;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Player 3";
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.DodgerBlue;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button30.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.Color.White;
            this.button30.Location = new System.Drawing.Point(213, 136);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(110, 26);
            this.button30.TabIndex = 66;
            this.button30.Text = "+50,000";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.DodgerBlue;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.ForeColor = System.Drawing.Color.White;
            this.button29.Location = new System.Drawing.Point(213, 162);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(110, 23);
            this.button29.TabIndex = 68;
            this.button29.Text = "Set Points";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(235, 90);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(54, 18);
            this.label31.TabIndex = 67;
            this.label31.Text = "Points:";
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.DodgerBlue;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button31.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.White;
            this.button31.Location = new System.Drawing.Point(259, 43);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(79, 26);
            this.button31.TabIndex = 65;
            this.button31.Text = "Off";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.DodgerBlue;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button32.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.ForeColor = System.Drawing.Color.White;
            this.button32.Location = new System.Drawing.Point(174, 43);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(79, 26);
            this.button32.TabIndex = 62;
            this.button32.Text = "On";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 18);
            this.label2.TabIndex = 75;
            this.label2.Text = "Weapon Swap";
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.DodgerBlue;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button34.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.ForeColor = System.Drawing.Color.White;
            this.button34.Location = new System.Drawing.Point(6, 43);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(77, 26);
            this.button34.TabIndex = 58;
            this.button34.Text = "On";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(59, 21);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(75, 18);
            this.label34.TabIndex = 60;
            this.label34.Text = "(Disabled)";
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(6, 22);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(79, 18);
            this.label35.TabIndex = 59;
            this.label35.Text = "GodMode:";
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.DodgerBlue;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.Red;
            this.button26.Location = new System.Drawing.Point(6, 241);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(97, 33);
            this.button26.TabIndex = 1;
            this.button26.Text = "Kick Player";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // player3
            // 
            this.player3.AutoSize = true;
            this.player3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player3.ForeColor = System.Drawing.Color.Gray;
            this.player3.Location = new System.Drawing.Point(235, 249);
            this.player3.Name = "player3";
            this.player3.Size = new System.Drawing.Size(45, 16);
            this.player3.TabIndex = 55;
            this.player3.Text = "None";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(183, 249);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 16);
            this.label30.TabIndex = 54;
            this.label30.Text = "Name:";
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.DodgerBlue;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button37.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.ForeColor = System.Drawing.Color.White;
            this.button37.Location = new System.Drawing.Point(6, 162);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(113, 23);
            this.button37.TabIndex = 70;
            this.button37.Text = "Give Gun";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(171, 21);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(79, 18);
            this.label33.TabIndex = 63;
            this.label33.Text = "Inf. Ammo:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(233, 21);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(75, 18);
            this.label32.TabIndex = 64;
            this.label32.Text = "(Disabled)";
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.DodgerBlue;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button33.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.ForeColor = System.Drawing.Color.White;
            this.button33.Location = new System.Drawing.Point(89, 43);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(79, 26);
            this.button33.TabIndex = 61;
            this.button33.Text = "Off";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.DodgerBlue;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button27.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.ForeColor = System.Drawing.Color.White;
            this.button27.Location = new System.Drawing.Point(6, 133);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(113, 23);
            this.button27.TabIndex = 71;
            this.button27.Text = "Weapon IDs";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // p3weaponid
            // 
            this.p3weaponid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.p3weaponid.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p3weaponid.Location = new System.Drawing.Point(6, 107);
            this.p3weaponid.Name = "p3weaponid";
            this.p3weaponid.Size = new System.Drawing.Size(84, 16);
            this.p3weaponid.TabIndex = 69;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.DodgerBlue;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.Color.White;
            this.button28.Location = new System.Drawing.Point(6, 162);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(113, 23);
            this.button28.TabIndex = 70;
            this.button28.Text = "Give Gun";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(3, 92);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(105, 18);
            this.label36.TabIndex = 74;
            this.label36.Text = "Weapon Swap";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button35);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.button43);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.button42);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.button36);
            this.groupBox6.Controls.Add(this.p4weaponid);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Controls.Add(this.button41);
            this.groupBox6.Controls.Add(this.button28);
            this.groupBox6.Controls.Add(this.button40);
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.label39);
            this.groupBox6.Controls.Add(this.numericUpDown4);
            this.groupBox6.Controls.Add(this.button39);
            this.groupBox6.Controls.Add(this.button38);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Controls.Add(this.player4);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox6.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(819, 331);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(349, 280);
            this.groupBox6.TabIndex = 72;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Player 4";
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.DodgerBlue;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.ForeColor = System.Drawing.Color.Red;
            this.button35.Location = new System.Drawing.Point(6, 241);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(99, 33);
            this.button35.TabIndex = 1;
            this.button35.Text = "Kick Player";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(65, 19);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(73, 18);
            this.label42.TabIndex = 60;
            this.label42.Text = "[Disabled]";
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.DodgerBlue;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button43.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.ForeColor = System.Drawing.Color.White;
            this.button43.Location = new System.Drawing.Point(6, 41);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(79, 26);
            this.button43.TabIndex = 58;
            this.button43.Text = "On";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.DodgerBlue;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button42.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.ForeColor = System.Drawing.Color.White;
            this.button42.Location = new System.Drawing.Point(91, 41);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(79, 26);
            this.button42.TabIndex = 61;
            this.button42.Text = "Off";
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(6, 19);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(79, 18);
            this.label43.TabIndex = 59;
            this.label43.Text = "GodMode:";
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.DodgerBlue;
            this.button36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button36.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.ForeColor = System.Drawing.Color.White;
            this.button36.Location = new System.Drawing.Point(6, 133);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(113, 23);
            this.button36.TabIndex = 71;
            this.button36.Text = "Weapon IDs";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // p4weaponid
            // 
            this.p4weaponid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.p4weaponid.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p4weaponid.Location = new System.Drawing.Point(6, 110);
            this.p4weaponid.Name = "p4weaponid";
            this.p4weaponid.Size = new System.Drawing.Size(84, 16);
            this.p4weaponid.TabIndex = 69;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(184, 17);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(79, 18);
            this.label41.TabIndex = 63;
            this.label41.Text = "Inf. Ammo:";
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.DodgerBlue;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button41.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.ForeColor = System.Drawing.Color.White;
            this.button41.Location = new System.Drawing.Point(176, 41);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(79, 26);
            this.button41.TabIndex = 62;
            this.button41.Text = "On";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.DodgerBlue;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button40.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.ForeColor = System.Drawing.Color.White;
            this.button40.Location = new System.Drawing.Point(261, 41);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(79, 26);
            this.button40.TabIndex = 65;
            this.button40.Text = "Off";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label40.ForeColor = System.Drawing.Color.Red;
            this.label40.Location = new System.Drawing.Point(256, 17);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(75, 18);
            this.label40.TabIndex = 64;
            this.label40.Text = "(Disabled)";
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(184, 89);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(54, 18);
            this.label39.TabIndex = 67;
            this.label39.Text = "Points:";
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.DodgerBlue;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button39.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.ForeColor = System.Drawing.Color.White;
            this.button39.Location = new System.Drawing.Point(172, 133);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(112, 23);
            this.button39.TabIndex = 66;
            this.button39.Text = "+50,000";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.DodgerBlue;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button38.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.ForeColor = System.Drawing.Color.White;
            this.button38.Location = new System.Drawing.Point(172, 162);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(112, 23);
            this.button38.TabIndex = 68;
            this.button38.Text = "Set Points";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(156, 252);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 16);
            this.label38.TabIndex = 54;
            this.label38.Text = "Name:";
            // 
            // player4
            // 
            this.player4.AutoSize = true;
            this.player4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player4.ForeColor = System.Drawing.Color.Gray;
            this.player4.Location = new System.Drawing.Point(208, 252);
            this.player4.Name = "player4";
            this.player4.Size = new System.Drawing.Size(45, 16);
            this.player4.TabIndex = 55;
            this.player4.Text = "None";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.ForeColor = System.Drawing.Color.White;
            this.checkBox2.Location = new System.Drawing.Point(200, 144);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(108, 20);
            this.checkBox2.TabIndex = 90;
            this.checkBox2.Text = "Activate XP";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.White;
            this.checkBox1.Location = new System.Drawing.Point(9, 144);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(150, 20);
            this.checkBox1.TabIndex = 89;
            this.checkBox1.Text = "Teleport Zombies";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.DodgerBlue;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button47.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.ForeColor = System.Drawing.Color.White;
            this.button47.Location = new System.Drawing.Point(92, 80);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(80, 26);
            this.button47.TabIndex = 87;
            this.button47.Text = "Off";
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label48.ForeColor = System.Drawing.Color.Red;
            this.label48.Location = new System.Drawing.Point(76, 61);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(73, 18);
            this.label48.TabIndex = 86;
            this.label48.Text = "[Disabled]";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(6, 61);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(78, 18);
            this.label49.TabIndex = 85;
            this.label49.Text = "Instant Kill:";
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.DodgerBlue;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button48.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.ForeColor = System.Drawing.Color.White;
            this.button48.Location = new System.Drawing.Point(9, 80);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(77, 26);
            this.button48.TabIndex = 84;
            this.button48.Text = "On";
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.DodgerBlue;
            this.button46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button46.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.ForeColor = System.Drawing.Color.White;
            this.button46.Location = new System.Drawing.Point(6, 17);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(334, 30);
            this.button46.TabIndex = 83;
            this.button46.Text = "Attach";
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label46.Location = new System.Drawing.Point(76, 215);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(26, 16);
            this.label46.TabIndex = 82;
            this.label46.Text = "1x";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Transparent;
            this.label47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label47.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(6, 215);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(64, 16);
            this.label47.TabIndex = 80;
            this.label47.Text = "Gun XP:";
            // 
            // trackBar2
            // 
            this.trackBar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(59)))));
            this.trackBar2.Location = new System.Drawing.Point(6, 232);
            this.trackBar2.Maximum = 5000;
            this.trackBar2.Minimum = 1;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(325, 45);
            this.trackBar2.TabIndex = 79;
            this.trackBar2.Value = 1;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label45.Location = new System.Drawing.Point(80, 167);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(26, 16);
            this.label45.TabIndex = 78;
            this.label45.Text = "1x";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label44.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(7, 167);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(71, 16);
            this.label44.TabIndex = 76;
            this.label44.Text = "Rank XP:";
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(59)))));
            this.trackBar1.Location = new System.Drawing.Point(6, 186);
            this.trackBar1.Maximum = 10000;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(325, 45);
            this.trackBar1.TabIndex = 61;
            this.trackBar1.Value = 1;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // timer1
            // 
            this.timer1.Interval = 250;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 150;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label29.Location = new System.Drawing.Point(281, 66);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(0, 14);
            this.label29.TabIndex = 80;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(639, 611);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 16);
            this.label1.TabIndex = 81;
            this.label1.Text = "http://discord.io/spacedoutcw";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.button46);
            this.groupBox1.Controls.Add(this.trackBar2);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.trackBar1);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.button47);
            this.groupBox1.Controls.Add(this.button48);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(430, 184);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(349, 280);
            this.groupBox1.TabIndex = 82;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lobby";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox3.Location = new System.Drawing.Point(200, 121);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(95, 20);
            this.checkBox3.TabIndex = 92;
            this.checkBox3.Text = "Crits Only";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DodgerBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(9, 115);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 26);
            this.button2.TabIndex = 91;
            this.button2.Text = "DISABLED";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button60_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(59)))));
            this.ClientSize = new System.Drawing.Size(1194, 631);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.tuulname);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Leave += new System.EventHandler(this.Form1_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		// Token: 0x04000051 RID: 81
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000052 RID: 82
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000053 RID: 83
		private global::System.Windows.Forms.ImageList imageList1;

		// Token: 0x04000054 RID: 84
		private global::System.Windows.Forms.Label label11;

		// Token: 0x04000055 RID: 85
		private global::System.Windows.Forms.Label label7;

		// Token: 0x04000056 RID: 86
		private global::System.Windows.Forms.Label label8;

		// Token: 0x04000057 RID: 87
		private global::System.Windows.Forms.Label label10;

		// Token: 0x04000058 RID: 88
		private global::System.Windows.Forms.Label label9;

		// Token: 0x04000059 RID: 89
		private global::System.Windows.Forms.Button button14;

		// Token: 0x0400005A RID: 90
		private global::System.Windows.Forms.Label label19;

		// Token: 0x0400005B RID: 91
		private global::System.Windows.Forms.Button button15;

		// Token: 0x0400005C RID: 92
		private global::System.Windows.Forms.Button button10;

		// Token: 0x0400005D RID: 93
		private global::System.Windows.Forms.Label label14;

		// Token: 0x0400005E RID: 94
		private global::System.Windows.Forms.Label label15;

		// Token: 0x0400005F RID: 95
		private global::System.Windows.Forms.Button button11;

		// Token: 0x04000060 RID: 96
		private global::System.Windows.Forms.Button button9;

		// Token: 0x04000061 RID: 97
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000062 RID: 98
		private global::System.Windows.Forms.Label label13;

		// Token: 0x04000063 RID: 99
		private global::System.Windows.Forms.Button button8;

		// Token: 0x04000064 RID: 100
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x04000065 RID: 101
		private global::System.Windows.Forms.Button button16;

		// Token: 0x04000066 RID: 102
		private global::System.Windows.Forms.Label player1;

		// Token: 0x04000067 RID: 103
		private global::System.Windows.Forms.Label label17;

		// Token: 0x04000068 RID: 104
		private global::System.Windows.Forms.Button button13;

		// Token: 0x04000069 RID: 105
		private global::System.Windows.Forms.Button button12;

		// Token: 0x0400006A RID: 106
		private global::System.Windows.Forms.TextBox p1weaponid;

		// Token: 0x0400006B RID: 107
		private global::System.ComponentModel.BackgroundWorker backgroundWorker1;

		// Token: 0x0400006C RID: 108
		private global::System.Windows.Forms.NumericUpDown numericUpDown1;

		// Token: 0x0400006D RID: 109
		private global::System.Windows.Forms.Label label20;

		// Token: 0x0400006E RID: 110
		private global::System.Windows.Forms.NumericUpDown numericUpDown2;

		// Token: 0x0400006F RID: 111
		private global::System.Windows.Forms.GroupBox groupBox4;

		// Token: 0x04000070 RID: 112
		private global::System.Windows.Forms.Button button17;

		// Token: 0x04000071 RID: 113
		private global::System.Windows.Forms.Label player2;

		// Token: 0x04000072 RID: 114
		private global::System.Windows.Forms.Label label22;

		// Token: 0x04000073 RID: 115
		private global::System.Windows.Forms.Button button18;

		// Token: 0x04000074 RID: 116
		private global::System.Windows.Forms.Button button19;

		// Token: 0x04000075 RID: 117
		private global::System.Windows.Forms.TextBox p2weaponid;

		// Token: 0x04000076 RID: 118
		private global::System.Windows.Forms.Button button20;

		// Token: 0x04000077 RID: 119
		private global::System.Windows.Forms.Label label23;

		// Token: 0x04000078 RID: 120
		private global::System.Windows.Forms.Button button21;

		// Token: 0x04000079 RID: 121
		private global::System.Windows.Forms.Button button22;

		// Token: 0x0400007A RID: 122
		private global::System.Windows.Forms.Label label24;

		// Token: 0x0400007B RID: 123
		private global::System.Windows.Forms.Label label25;

		// Token: 0x0400007C RID: 124
		private global::System.Windows.Forms.Button button23;

		// Token: 0x0400007D RID: 125
		private global::System.Windows.Forms.Button button24;

		// Token: 0x0400007E RID: 126
		private global::System.Windows.Forms.Label label26;

		// Token: 0x0400007F RID: 127
		private global::System.Windows.Forms.Label label27;

		// Token: 0x04000080 RID: 128
		private global::System.Windows.Forms.Button button25;

		// Token: 0x04000081 RID: 129
		private global::System.Windows.Forms.NumericUpDown numericUpDown3;

		// Token: 0x04000082 RID: 130
		private global::System.Windows.Forms.GroupBox groupBox5;

		// Token: 0x04000083 RID: 131
		private global::System.Windows.Forms.Button button26;

		// Token: 0x04000084 RID: 132
		private global::System.Windows.Forms.Label player3;

		// Token: 0x04000085 RID: 133
		private global::System.Windows.Forms.Label label30;

		// Token: 0x04000086 RID: 134
		private global::System.Windows.Forms.Button button27;

		// Token: 0x04000087 RID: 135
		private global::System.Windows.Forms.Button button28;

		// Token: 0x04000088 RID: 136
		private global::System.Windows.Forms.TextBox p3weaponid;

		// Token: 0x04000089 RID: 137
		private global::System.Windows.Forms.Button button29;

		// Token: 0x0400008A RID: 138
		private global::System.Windows.Forms.Label label31;

		// Token: 0x0400008B RID: 139
		private global::System.Windows.Forms.Button button30;

		// Token: 0x0400008C RID: 140
		private global::System.Windows.Forms.Button button31;

		// Token: 0x0400008D RID: 141
		private global::System.Windows.Forms.Label label32;

		// Token: 0x0400008E RID: 142
		private global::System.Windows.Forms.Label label33;

		// Token: 0x0400008F RID: 143
		private global::System.Windows.Forms.Button button32;

		// Token: 0x04000090 RID: 144
		private global::System.Windows.Forms.Button button33;

		// Token: 0x04000091 RID: 145
		private global::System.Windows.Forms.Label label34;

		// Token: 0x04000092 RID: 146
		private global::System.Windows.Forms.Label label35;

		// Token: 0x04000093 RID: 147
		private global::System.Windows.Forms.Button button34;

		// Token: 0x04000094 RID: 148
		private global::System.Windows.Forms.Label label36;

		// Token: 0x04000095 RID: 149
		private global::System.Windows.Forms.NumericUpDown numericUpDown4;

		// Token: 0x04000096 RID: 150
		private global::System.Windows.Forms.GroupBox groupBox6;

		// Token: 0x04000097 RID: 151
		private global::System.Windows.Forms.Button button35;

		// Token: 0x04000098 RID: 152
		private global::System.Windows.Forms.Label player4;

		// Token: 0x04000099 RID: 153
		private global::System.Windows.Forms.Label label38;

		// Token: 0x0400009A RID: 154
		private global::System.Windows.Forms.Button button36;

		// Token: 0x0400009B RID: 155
		private global::System.Windows.Forms.Button button37;

		// Token: 0x0400009C RID: 156
		private global::System.Windows.Forms.TextBox p4weaponid;

		// Token: 0x0400009D RID: 157
		private global::System.Windows.Forms.Button button38;

		// Token: 0x0400009E RID: 158
		private global::System.Windows.Forms.Label label39;

		// Token: 0x0400009F RID: 159
		private global::System.Windows.Forms.Button button39;

		// Token: 0x040000A0 RID: 160
		private global::System.Windows.Forms.Button button40;

		// Token: 0x040000A1 RID: 161
		private global::System.Windows.Forms.Label label40;

		// Token: 0x040000A2 RID: 162
		private global::System.Windows.Forms.Label label41;

		// Token: 0x040000A3 RID: 163
		private global::System.Windows.Forms.Button button41;

		// Token: 0x040000A4 RID: 164
		private global::System.Windows.Forms.Button button42;

		// Token: 0x040000A5 RID: 165
		private global::System.Windows.Forms.Label label42;

		// Token: 0x040000A6 RID: 166
		private global::System.Windows.Forms.Label label43;

		// Token: 0x040000A7 RID: 167
		private global::System.Windows.Forms.Button button43;

		// Token: 0x040000A8 RID: 168
		private global::System.Windows.Forms.Label label45;

		// Token: 0x040000A9 RID: 169
		private global::System.Windows.Forms.Label label44;

		// Token: 0x040000AA RID: 170
		private global::System.Windows.Forms.TrackBar trackBar1;

		// Token: 0x040000AB RID: 171
		private global::System.Windows.Forms.Label label46;

		// Token: 0x040000AC RID: 172
		private global::System.Windows.Forms.Label label47;

		// Token: 0x040000AD RID: 173
		private global::System.Windows.Forms.TrackBar trackBar2;

		// Token: 0x040000AE RID: 174
		private global::System.Windows.Forms.Button button47;

		// Token: 0x040000AF RID: 175
		private global::System.Windows.Forms.Label label48;

		// Token: 0x040000B0 RID: 176
		private global::System.Windows.Forms.Label label49;

		// Token: 0x040000B1 RID: 177
		private global::System.Windows.Forms.Button button48;

		// Token: 0x040000B2 RID: 178
		private global::System.Windows.Forms.Button button46;

		// Token: 0x040000B3 RID: 179
		private global::System.Windows.Forms.CheckBox checkBox1;

		// Token: 0x040000B4 RID: 180
		private global::System.Windows.Forms.Label tuulname;

		// Token: 0x040000B5 RID: 181
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x040000B6 RID: 182
		private global::System.Windows.Forms.CheckBox checkBox2;

		// Token: 0x040000B7 RID: 183
		private global::System.Windows.Forms.Timer timer2;

		// Token: 0x040000B8 RID: 184
		private global::System.Windows.Forms.Label label29;

		// Token: 0x040000B9 RID: 185
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000BA RID: 186
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040000BB RID: 187
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x040000BC RID: 188
		private global::System.Windows.Forms.Label label3;

		// Token: 0x040000BD RID: 189
		private global::System.Windows.Forms.Button button2;

		// Token: 0x040000BE RID: 190
		private global::System.Windows.Forms.CheckBox checkBox3;
	}
}
