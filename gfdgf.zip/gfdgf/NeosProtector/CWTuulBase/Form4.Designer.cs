﻿namespace CWTuulBase
{
	// Token: 0x02000007 RID: 7
	public partial class Form4 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000099 RID: 153 RVA: 0x0000B7CC File Offset: 0x000099CC
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x0000B804 File Offset: 0x00009A04
		private void InitializeComponent()
		{
			this.jFlatButton2 = new global::FlatButton.JFlatButton();
			this.jFlatButton1 = new global::FlatButton.JFlatButton();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.jThinButton1 = new global::JThinButton.JThinButton();
			this.jThinButton2 = new global::JThinButton.JThinButton();
			this.rectangleShape2 = new global::Microsoft.VisualBasic.PowerPacks.RectangleShape();
			this.rectangleShape1 = new global::Microsoft.VisualBasic.PowerPacks.RectangleShape();
			this.shapeContainer1 = new global::Microsoft.VisualBasic.PowerPacks.ShapeContainer();
			this.rectangleShape4 = new global::Microsoft.VisualBasic.PowerPacks.RectangleShape();
			this.rectangleShape3 = new global::Microsoft.VisualBasic.PowerPacks.RectangleShape();
			this.password = new global::System.Windows.Forms.TextBox();
			this.username = new global::System.Windows.Forms.TextBox();
			this.license = new global::System.Windows.Forms.TextBox();
			this.email = new global::System.Windows.Forms.TextBox();
			base.SuspendLayout();
			this.jFlatButton2.BackColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton2.BackgroundColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton2.ButtonText = "-";
			this.jFlatButton2.CausesValidation = false;
			this.jFlatButton2.ErrorImageLeft = null;
			this.jFlatButton2.ErrorImageRight = null;
			this.jFlatButton2.FocusBackground = global::System.Drawing.Color.Empty;
			this.jFlatButton2.FocusFontColor = global::System.Drawing.Color.Empty;
			this.jFlatButton2.ForeColors = global::System.Drawing.Color.White;
			this.jFlatButton2.HoverBackground = global::System.Drawing.Color.Empty;
			this.jFlatButton2.HoverFontColor = global::System.Drawing.Color.Empty;
			this.jFlatButton2.ImageLeft = null;
			this.jFlatButton2.ImageRight = null;
			this.jFlatButton2.LeftPictureColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton2.Location = new global::System.Drawing.Point(229, 0);
			this.jFlatButton2.Name = "jFlatButton2";
			this.jFlatButton2.PaddingLeftPicture = new global::System.Windows.Forms.Padding(0);
			this.jFlatButton2.PaddingRightPicture = new global::System.Windows.Forms.Padding(0);
			this.jFlatButton2.RightPictureColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton2.Size = new global::System.Drawing.Size(47, 25);
			this.jFlatButton2.SizeModeLeft = global::System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.jFlatButton2.SizeModeRight = global::System.Windows.Forms.PictureBoxSizeMode.Normal;
			this.jFlatButton2.TabIndex = 15;
			this.jFlatButton1.BackColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton1.BackgroundColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton1.ButtonText = "X";
			this.jFlatButton1.CausesValidation = false;
			this.jFlatButton1.ErrorImageLeft = null;
			this.jFlatButton1.ErrorImageRight = null;
			this.jFlatButton1.FocusBackground = global::System.Drawing.Color.Empty;
			this.jFlatButton1.FocusFontColor = global::System.Drawing.Color.Empty;
			this.jFlatButton1.ForeColors = global::System.Drawing.Color.White;
			this.jFlatButton1.HoverBackground = global::System.Drawing.Color.Empty;
			this.jFlatButton1.HoverFontColor = global::System.Drawing.Color.Empty;
			this.jFlatButton1.ImageLeft = null;
			this.jFlatButton1.ImageRight = null;
			this.jFlatButton1.LeftPictureColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton1.Location = new global::System.Drawing.Point(276, 0);
			this.jFlatButton1.Name = "jFlatButton1";
			this.jFlatButton1.PaddingLeftPicture = new global::System.Windows.Forms.Padding(0);
			this.jFlatButton1.PaddingRightPicture = new global::System.Windows.Forms.Padding(0);
			this.jFlatButton1.RightPictureColor = global::System.Drawing.Color.Transparent;
			this.jFlatButton1.Size = new global::System.Drawing.Size(47, 25);
			this.jFlatButton1.SizeModeLeft = global::System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.jFlatButton1.SizeModeRight = global::System.Windows.Forms.PictureBoxSizeMode.Normal;
			this.jFlatButton1.TabIndex = 14;
			this.jFlatButton1.Click += new global::System.EventHandler(this.jFlatButton1_Click);
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label2.ForeColor = global::System.Drawing.Color.Crimson;
			this.label2.Location = new global::System.Drawing.Point(12, 9);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(119, 16);
			this.label2.TabIndex = 13;
			this.label2.Text = "HypeTool | Auth";
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Base 05", 24f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.Color.White;
			this.label1.Location = new global::System.Drawing.Point(36, 45);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(257, 40);
			this.label1.TabIndex = 12;
			this.label1.Text = "HYPECHEATS";
			this.jThinButton1.BackColor = global::System.Drawing.Color.Transparent;
			this.jThinButton1.BackgroundColor = global::System.Drawing.Color.Crimson;
			this.jThinButton1.BorderColor = global::System.Drawing.Color.Crimson;
			this.jThinButton1.BorderRadius = 11;
			this.jThinButton1.ButtonText = "Back To Login";
			this.jThinButton1.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.jThinButton1.Font_Size = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.jThinButton1.ForeColors = global::System.Drawing.Color.White;
			this.jThinButton1.HoverBackground = global::System.Drawing.Color.White;
			this.jThinButton1.HoverBorder = global::System.Drawing.Color.Empty;
			this.jThinButton1.HoverFontColor = global::System.Drawing.SystemColors.Highlight;
			this.jThinButton1.LineThickness = 2;
			this.jThinButton1.Location = new global::System.Drawing.Point(34, 283);
			this.jThinButton1.Margin = new global::System.Windows.Forms.Padding(4, 3, 4, 3);
			this.jThinButton1.Name = "jThinButton1";
			this.jThinButton1.Size = new global::System.Drawing.Size(255, 27);
			this.jThinButton1.TabIndex = 20;
			this.jThinButton1.Click += new global::System.EventHandler(this.jThinButton1_Click);
			this.jThinButton2.BackColor = global::System.Drawing.Color.Transparent;
			this.jThinButton2.BackgroundColor = global::System.Drawing.Color.Crimson;
			this.jThinButton2.BorderColor = global::System.Drawing.Color.Crimson;
			this.jThinButton2.BorderRadius = 11;
			this.jThinButton2.ButtonText = "Register";
			this.jThinButton2.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.jThinButton2.Font_Size = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.jThinButton2.ForeColors = global::System.Drawing.Color.White;
			this.jThinButton2.HoverBackground = global::System.Drawing.Color.White;
			this.jThinButton2.HoverBorder = global::System.Drawing.Color.Empty;
			this.jThinButton2.HoverFontColor = global::System.Drawing.SystemColors.Highlight;
			this.jThinButton2.LineThickness = 2;
			this.jThinButton2.Location = new global::System.Drawing.Point(34, 250);
			this.jThinButton2.Margin = new global::System.Windows.Forms.Padding(4, 4, 4, 4);
			this.jThinButton2.Name = "jThinButton2";
			this.jThinButton2.Size = new global::System.Drawing.Size(255, 27);
			this.jThinButton2.TabIndex = 21;
			this.jThinButton2.Click += new global::System.EventHandler(this.jThinButton2_Click);
			this.rectangleShape2.BorderColor = global::System.Drawing.Color.Crimson;
			this.rectangleShape2.BorderWidth = 2;
			this.rectangleShape2.CornerRadius = 10;
			this.rectangleShape2.Location = new global::System.Drawing.Point(44, 131);
			this.rectangleShape2.Name = "rectangleShape2";
			this.rectangleShape2.Size = new global::System.Drawing.Size(236, 30);
			this.rectangleShape1.BorderColor = global::System.Drawing.Color.Crimson;
			this.rectangleShape1.BorderWidth = 2;
			this.rectangleShape1.CornerRadius = 10;
			this.rectangleShape1.Location = new global::System.Drawing.Point(44, 93);
			this.rectangleShape1.Name = "rectangleShape1";
			this.rectangleShape1.Size = new global::System.Drawing.Size(236, 30);
			this.shapeContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.shapeContainer1.Margin = new global::System.Windows.Forms.Padding(0);
			this.shapeContainer1.Name = "shapeContainer1";
			this.shapeContainer1.Shapes.AddRange(new global::Microsoft.VisualBasic.PowerPacks.Shape[]
			{
				this.rectangleShape4,
				this.rectangleShape3,
				this.rectangleShape1,
				this.rectangleShape2
			});
			this.shapeContainer1.Size = new global::System.Drawing.Size(324, 321);
			this.shapeContainer1.TabIndex = 22;
			this.shapeContainer1.TabStop = false;
			this.rectangleShape4.BorderColor = global::System.Drawing.Color.Crimson;
			this.rectangleShape4.BorderWidth = 2;
			this.rectangleShape4.CornerRadius = 10;
			this.rectangleShape4.Location = new global::System.Drawing.Point(43, 169);
			this.rectangleShape4.Name = "rectangleShape4";
			this.rectangleShape4.Size = new global::System.Drawing.Size(236, 30);
			this.rectangleShape3.BorderColor = global::System.Drawing.Color.Crimson;
			this.rectangleShape3.BorderWidth = 2;
			this.rectangleShape3.CornerRadius = 10;
			this.rectangleShape3.Location = new global::System.Drawing.Point(43, 207);
			this.rectangleShape3.Name = "rectangleShape3";
			this.rectangleShape3.Size = new global::System.Drawing.Size(236, 30);
			this.password.BackColor = global::System.Drawing.Color.FromArgb(35, 39, 42);
			this.password.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.password.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.password.ForeColor = global::System.Drawing.Color.White;
			this.password.Location = new global::System.Drawing.Point(57, 138);
			this.password.Name = "password";
			this.password.Size = new global::System.Drawing.Size(198, 15);
			this.password.TabIndex = 24;
			this.password.Text = "Password";
			this.username.BackColor = global::System.Drawing.Color.FromArgb(35, 39, 42);
			this.username.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.username.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.username.ForeColor = global::System.Drawing.Color.White;
			this.username.Location = new global::System.Drawing.Point(57, 100);
			this.username.Name = "username";
			this.username.Size = new global::System.Drawing.Size(198, 15);
			this.username.TabIndex = 23;
			this.username.Text = "Username";
			this.license.BackColor = global::System.Drawing.Color.FromArgb(35, 39, 42);
			this.license.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.license.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.license.ForeColor = global::System.Drawing.Color.White;
			this.license.Location = new global::System.Drawing.Point(57, 215);
			this.license.Name = "license";
			this.license.Size = new global::System.Drawing.Size(198, 15);
			this.license.TabIndex = 26;
			this.license.Text = "License";
			this.email.BackColor = global::System.Drawing.Color.FromArgb(35, 39, 42);
			this.email.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.email.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.email.ForeColor = global::System.Drawing.Color.White;
			this.email.Location = new global::System.Drawing.Point(57, 177);
			this.email.Name = "email";
			this.email.Size = new global::System.Drawing.Size(198, 15);
			this.email.TabIndex = 25;
			this.email.Text = "Email";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(35, 39, 42);
			base.ClientSize = new global::System.Drawing.Size(324, 321);
			base.Controls.Add(this.license);
			base.Controls.Add(this.email);
			base.Controls.Add(this.password);
			base.Controls.Add(this.username);
			base.Controls.Add(this.jThinButton2);
			base.Controls.Add(this.jThinButton1);
			base.Controls.Add(this.jFlatButton2);
			base.Controls.Add(this.jFlatButton1);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.shapeContainer1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Form4";
			this.Text = "Form4";
			base.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.Form4_MouseDown);
			base.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.Form4_MouseMove);
			base.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.Form4_MouseUp);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040000DE RID: 222
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x040000DF RID: 223
		private global::FlatButton.JFlatButton jFlatButton2;

		// Token: 0x040000E0 RID: 224
		private global::FlatButton.JFlatButton jFlatButton1;

		// Token: 0x040000E1 RID: 225
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040000E2 RID: 226
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000E3 RID: 227
		private global::JThinButton.JThinButton jThinButton1;

		// Token: 0x040000E4 RID: 228
		private global::JThinButton.JThinButton jThinButton2;

		// Token: 0x040000E5 RID: 229
		private global::Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;

		// Token: 0x040000E6 RID: 230
		private global::Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;

		// Token: 0x040000E7 RID: 231
		private global::Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;

		// Token: 0x040000E8 RID: 232
		private global::Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;

		// Token: 0x040000E9 RID: 233
		private global::Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;

		// Token: 0x040000EA RID: 234
		private global::System.Windows.Forms.TextBox password;

		// Token: 0x040000EB RID: 235
		private global::System.Windows.Forms.TextBox username;

		// Token: 0x040000EC RID: 236
		private global::System.Windows.Forms.TextBox license;

		// Token: 0x040000ED RID: 237
		private global::System.Windows.Forms.TextBox email;
	}
}
