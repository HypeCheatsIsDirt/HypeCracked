﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using FlatButton;
using JThinButton;
using Microsoft.VisualBasic.PowerPacks;

namespace CWTuulBase
{
	// Token: 0x02000006 RID: 6
	public partial class Form3 : Form
	{
		// Token: 0x06000089 RID: 137 RVA: 0x00002370 File Offset: 0x00000570
		public Form3()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600008A RID: 138 RVA: 0x0000AA4C File Offset: 0x00008C4C
		private void JThinButton1_Click(object sender, EventArgs e)
		{
			new Form1();
		}

		// Token: 0x0600008B RID: 139 RVA: 0x0000AAA4 File Offset: 0x00008CA4
		private void JThinButton2_Click(object sender, EventArgs e)
		{
			Form4 form = new Form4();
			form.Show();
			base.Hide();
		}

		// Token: 0x0600008C RID: 140 RVA: 0x0000239C File Offset: 0x0000059C
		private void JFlatButton1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x000023A5 File Offset: 0x000005A5
		private void Form3_MouseDown(object sender, MouseEventArgs e)
		{
			this._dragging = true;
			this._start_point = new Point(e.X, e.Y);
		}

		// Token: 0x0600008E RID: 142 RVA: 0x0000AAC8 File Offset: 0x00008CC8
		private void Form3_MouseMove(object sender, MouseEventArgs e)
		{
			bool dragging = this._dragging;
			if (dragging)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this._start_point.X, point.Y - this._start_point.Y);
			}
		}

		// Token: 0x0600008F RID: 143 RVA: 0x000023C6 File Offset: 0x000005C6
		private void Form3_MouseUp(object sender, MouseEventArgs e)
		{
			this._dragging = false;
		}

		// Token: 0x040000CC RID: 204
		private bool _dragging = false;

		// Token: 0x040000CD RID: 205
		private Point _offset;

		// Token: 0x040000CE RID: 206
		private Point _start_point = new Point(0, 0);
	}
}
