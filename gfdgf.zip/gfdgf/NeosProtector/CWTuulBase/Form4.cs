﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using FlatButton;
using JThinButton;
using Microsoft.VisualBasic.PowerPacks;

namespace CWTuulBase
{
	// Token: 0x02000007 RID: 7
	public partial class Form4 : Form
	{
		// Token: 0x06000092 RID: 146 RVA: 0x000023D0 File Offset: 0x000005D0
		public Form4()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000093 RID: 147 RVA: 0x0000B6F4 File Offset: 0x000098F4
		private void jThinButton1_Click(object sender, EventArgs e)
		{
			Form3 form = new Form3();
			form.Show();
			base.Hide();
		}

		// Token: 0x06000094 RID: 148 RVA: 0x0000239C File Offset: 0x0000059C
		private void jFlatButton1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000095 RID: 149 RVA: 0x0000B718 File Offset: 0x00009918
		private void jThinButton2_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000023FC File Offset: 0x000005FC
		private void Form4_MouseDown(object sender, MouseEventArgs e)
		{
			this._dragging = true;
			this._start_point = new Point(e.X, e.Y);
		}

		// Token: 0x06000097 RID: 151 RVA: 0x0000B770 File Offset: 0x00009970
		private void Form4_MouseMove(object sender, MouseEventArgs e)
		{
			bool dragging = this._dragging;
			if (dragging)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this._start_point.X, point.Y - this._start_point.Y);
			}
		}

		// Token: 0x06000098 RID: 152 RVA: 0x0000241D File Offset: 0x0000061D
		private void Form4_MouseUp(object sender, MouseEventArgs e)
		{
			this._dragging = false;
		}

		// Token: 0x040000DB RID: 219
		private bool _dragging = false;

		// Token: 0x040000DC RID: 220
		private Point _offset;

		// Token: 0x040000DD RID: 221
		private Point _start_point = new Point(0, 0);
	}
}
