﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using cw;

namespace CWTuulBase
{
	// Token: 0x02000003 RID: 3
	public partial class Form1 : Form
	{
		// Token: 0x06000023 RID: 35
		[DllImport("Gdi32.dll")]
		private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

		// Token: 0x06000024 RID: 36 RVA: 0x00002CD4 File Offset: 0x00000ED4
		public Form1()
		{
			this.InitializeComponent();
			base.Region = Region.FromHrgn(Form1.CreateRoundRectRgn(0, 0, base.Width, base.Height, 20, 20));
		}

		// Token: 0x06000025 RID: 37 RVA: 0x0000205B File Offset: 0x0000025B
		private void button2_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000026 RID: 38 RVA: 0x0000205E File Offset: 0x0000025E
		private void button1_Click(object sender, EventArgs e)
		{
			Process.GetCurrentProcess().Kill();
		}

		// Token: 0x06000027 RID: 39 RVA: 0x0000206C File Offset: 0x0000026C
		private void button16_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Soon", "Basic Tuul Base", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00002082 File Offset: 0x00000282
		private void MouseUp_Event(object sender, MouseEventArgs e)
		{
			this.mouseDown = false;
		}

		// Token: 0x06000029 RID: 41 RVA: 0x0000208C File Offset: 0x0000028C
		private void MouseDown_Event(object sender, MouseEventArgs e)
		{
			this.offset.X = e.X;
			this.offset.Y = e.Y;
			this.mouseDown = true;
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00002E10 File Offset: 0x00001010
		private void MouseMove_Event(object sender, MouseEventArgs e)
		{
			bool flag = this.mouseDown;
			bool flag2 = flag;
			if (flag2)
			{
				Point point = base.PointToScreen(e.Location);
				base.Location = new Point(point.X - this.offset.X, point.Y - this.offset.Y);
			}
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002E6C File Offset: 0x0000106C
		private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
		{
			for (;;)
			{
				try
				{
					bool flag = !this.toolbaseon;
					bool flag2 = !flag;
					if (flag2)
					{
						Process[] processesByName = Process.GetProcessesByName("BlackOpsColdWar");
						bool flag3 = processesByName.Length < 1;
						bool flag4 = flag3;
						if (flag4)
						{
							this.UpdateLabel(this.label8, "{Game is not running}", "Orange");
						}
						else
						{
							this.gameProc = processesByName[0];
							this.gamePID = this.gameProc.Id;
							bool flag5 = this.gamePID > 0;
							bool flag6 = flag5;
							if (flag6)
							{
								this.UpdateLabel(this.label8, "{Game is running}", "Green");
								this.hProc = cwapi.OpenProcess(cwapi.ProcessAccessFlags.All, false, this.gameProc.Id);
								bool flag7 = this.baseAddress != cwapi.GetModuleBaseAddress(this.gameProc, "BlackOpsColdWar.exe");
								bool flag8 = flag7;
								if (flag8)
								{
									this.baseAddress = cwapi.GetModuleBaseAddress(this.gameProc, "BlackOpsColdWar.exe");
								}
								bool flag9 = this.PlayerCompPtr != cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64()), new int[1]);
								bool flag10 = flag9;
								if (flag10)
								{
									this.PlayerCompPtr = cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64()), new int[1]);
								}
								bool flag11 = this.PlayerPedPtr != cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64() + 8L), new int[1]);
								bool flag12 = flag11;
								if (flag12)
								{
									this.PlayerPedPtr = cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64() + 8L), new int[1]);
								}
								bool flag13 = this.ZMGlobalBase != cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64() + 96L), new int[1]);
								bool flag14 = flag13;
								if (flag14)
								{
									this.ZMGlobalBase = cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64() + 96L), new int[1]);
								}
								bool flag15 = this.ZMBotBase != cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64() + 104L), new int[1]);
								bool flag16 = flag15;
								if (flag16)
								{
									this.ZMBotBase = cwapi.FindDMAAddy(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.PlayerBase.ToInt64()) + 104, new int[1]);
								}
								bool flag17 = this.ZMBotBase != (IntPtr)0 && this.ZMBotBase != (IntPtr)104 && this.ZMBotListBase != cwapi.FindDMAAddy(this.hProc, this.ZMBotBase + 8, new int[1]);
								bool flag18 = flag17;
								if (flag18)
								{
									this.ZMBotListBase = cwapi.FindDMAAddy(this.hProc, this.ZMBotBase + 8, new int[1]);
								}
								byte[] array = new byte[12];
								IntPtr intPtr;
								cwapi.ReadProcessMemory(this.hProc, this.PlayerPedPtr + 724, array, 12L, out intPtr);
								float num = BitConverter.ToSingle(array, 0);
								float num2 = BitConverter.ToSingle(array, 4);
								float num3 = BitConverter.ToSingle(array, 8);
								this.updatedPlayerPos = new Vector3((float)Math.Round((double)num, 4), (float)Math.Round((double)num2, 4), (float)Math.Round((double)num3, 4));
								byte[] array2 = new byte[13];
								cwapi.ReadProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 23562, array2, 13L, out intPtr);
								string @string = Encoding.UTF8.GetString(array2);
								bool flag19 = @string.Equals("UnnamedPlayer");
								bool flag20 = flag19;
								if (flag20)
								{
									Application.Exit();
								}
								for (int i = 0; i < 4; i++)
								{
									byte[] array3 = new byte[100];
									cwapi.ReadProcessMemory(this.hProc, this.PlayerCompPtr + 47424 * i + 23562, array3, 100L, out intPtr);
									string string2 = Encoding.UTF8.GetString(array3);
									switch (i)
									{
									case 0:
										this.player1.Text = string2;
										break;
									case 1:
										this.player2.Text = string2;
										break;
									case 2:
										this.player3.Text = string2;
										break;
									case 3:
										this.player4.Text = string2;
										break;
									}
								}
								bool flag21 = this.instakill;
								bool flag22 = flag21;
								if (flag22)
								{
									for (int j = 0; j < 90; j++)
									{
										cwapi.WriteProcessMemory(this.hProc, this.ZMBotListBase + 1528 * j + 920, 1, 4L, out intPtr);
										cwapi.WriteProcessMemory(this.hProc, this.ZMBotListBase + 1528 * j + 924, 1, 4L, out intPtr);
									}
								}
								bool flag23 = this.p1ammo;
								bool flag24 = flag23;
								if (flag24)
								{
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 5076 + 4, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 5076 + 8, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 5076 + 12, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 5076 + 16, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 5076 + 20, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 5076 + 24, 256, 4L, out intPtr);
								}
								bool flag25 = this.p2ammo;
								bool flag26 = flag25;
								if (flag26)
								{
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 5076 + 4, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 5076 + 8, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 5076 + 12, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 5076 + 16, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 5076 + 20, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 5076 + 24, 256, 4L, out intPtr);
								}
								bool flag27 = this.p3ammo;
								bool flag28 = flag27;
								if (flag28)
								{
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 5076 + 4, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 5076 + 8, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 5076 + 12, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 5076 + 16, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 5076 + 20, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 5076 + 24, 256, 4L, out intPtr);
								}
								bool flag29 = this.p4ammo;
								bool flag30 = flag29;
								if (flag30)
								{
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 5076 + 4, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 5076 + 8, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 5076 + 12, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 5076 + 16, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 5076 + 20, 256, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 5076 + 24, 256, 4L, out intPtr);
								}
								bool flag31 = this.p1points;
								bool flag32 = flag31;
								if (flag32)
								{
									cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 23828, 50000, 4L, out intPtr);
								}
								bool flag33 = this.p2points;
								bool flag34 = flag33;
								if (flag34)
								{
									for (int k = 0; k < 4; k++)
									{
										cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 23828, 50000, 4L, out intPtr);
									}
								}
								bool flag35 = this.p3points;
								bool flag36 = flag35;
								if (flag36)
								{
									for (int l = 0; l < 4; l++)
									{
										cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 23828, 50000, 4L, out intPtr);
									}
								}
								bool flag37 = this.p4points;
								bool flag38 = flag37;
								if (flag38)
								{
									for (int m = 0; m < 4; m++)
									{
										cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 23828, 50000, 4L, out intPtr);
									}
								}
								bool @checked = this.checkBox2.Checked;
								bool flag39 = @checked;
								if (flag39)
								{
									byte[] array4 = new byte[4];
									Buffer.BlockCopy(BitConverter.GetBytes((float)this.trackBar1.Value), 0, array4, 0, 4);
									cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.XPScaleBase.ToInt64()) + 40, array4, 4L, out intPtr);
									cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.XPScaleBase.ToInt64()) + 48, array4, 4L, out intPtr);
									cwapi.ReadProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.XPScaleBase.ToInt64()) + 40, array4, 4L, out intPtr);
									byte[] array5 = new byte[4];
									Buffer.BlockCopy(BitConverter.GetBytes((float)this.trackBar2.Value), 0, array5, 0, 4);
									cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.XPScaleBase.ToInt64()) + 48, array5, 4L, out intPtr);
									cwapi.ReadProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.XPScaleBase.ToInt64()) + 48, array5, 4L, out intPtr);
								}
								bool checked2 = this.checkBox1.Checked;
								bool flag40 = checked2;
								if (flag40)
								{
									byte[] array6 = new byte[12];
									byte[] array7 = new byte[4];
									byte[] array8 = new byte[4];
									cwapi.ReadProcessMemory(this.hProc, this.PlayerPedPtr + 56, array7, 4L, out intPtr);
									cwapi.ReadProcessMemory(this.hProc, this.PlayerPedPtr + 52, array8, 4L, out intPtr);
									double num4 = -this.ConvertToRadians((double)BitConverter.ToSingle(array8, 0));
									double num5 = this.ConvertToRadians((double)BitConverter.ToSingle(array7, 0));
									float x = Convert.ToSingle(Math.Cos(num5) * Math.Cos(num4));
									float y = Convert.ToSingle(Math.Sin(num5) * Math.Cos(num4));
									float z = Convert.ToSingle(Math.Sin(num4));
									Vector3 vector = this.updatedPlayerPos + new Vector3(x, y, z) * 150f;
									Buffer.BlockCopy(BitConverter.GetBytes(vector.X), 0, array6, 0, 4);
									Buffer.BlockCopy(BitConverter.GetBytes(vector.Y), 0, array6, 4, 4);
									Buffer.BlockCopy(BitConverter.GetBytes(vector.Z), 0, array6, 8, 4);
									for (int n = 0; n < 90; n++)
									{
										cwapi.WriteProcessMemory(this.hProc, this.ZMBotListBase + 1528 * n + 724, array6, 12L, out intPtr);
									}
								}
								bool flag41 = Marshal.GetLastWin32Error() != 0;
								bool flag42 = flag41;
								if (flag42)
								{
									this.ConsoleOut(Marshal.GetLastWin32Error().ToString());
								}
							}
							else
							{
								this.UpdateLabel(this.label8, "{Game is not running}", "Red");
							}
						}
					}
				}
				catch (Exception ex)
				{
					this.ConsoleOut(ex.Message);
				}
			}
		}

		// Token: 0x0600002C RID: 44 RVA: 0x0000205B File Offset: 0x0000025B
		private void button3_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00003E90 File Offset: 0x00002090
		private void button8_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 3687, 160, 1L, out intPtr);
			this.label12.ForeColor = Color.GreenYellow;
			this.label12.Text = "[Enabled]";
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00003EEC File Offset: 0x000020EC
		private void button9_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 3687, 32, 1L, out intPtr);
			this.label12.ForeColor = Color.Red;
			this.label12.Text = "[Disabled]";
		}

		// Token: 0x0600002F RID: 47 RVA: 0x000020BA File Offset: 0x000002BA
		private void button11_Click(object sender, EventArgs e)
		{
			this.p1ammo = true;
			this.label14.ForeColor = Color.GreenYellow;
			this.label14.Text = "[Enabled]";
		}

		// Token: 0x06000030 RID: 48 RVA: 0x000020E6 File Offset: 0x000002E6
		private void button10_Click(object sender, EventArgs e)
		{
			this.p1ammo = false;
			this.label14.ForeColor = Color.Red;
			this.label14.Text = "[Disabled]";
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00002112 File Offset: 0x00000312
		private void button15_Click(object sender, EventArgs e)
		{
			this.p1points = true;
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003F44 File Offset: 0x00002144
		private void button14_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 23828, this.numericUpDown1.Value, 4L, out intPtr);
		}

		// Token: 0x06000033 RID: 51 RVA: 0x0000205B File Offset: 0x0000025B
		private void button4_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00003F84 File Offset: 0x00002184
		private void button12_Click(object sender, EventArgs e)
		{
			long num = long.Parse(this.p1weaponid.Text);
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 0 + 176, num, 8L, out intPtr);
		}

		// Token: 0x06000035 RID: 53 RVA: 0x0000211C File Offset: 0x0000031C
		private void button13_Click(object sender, EventArgs e)
		{
			Process.Start("https://pastebin.com/hKvLv6z8");
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00003FD0 File Offset: 0x000021D0
		private void button25_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 3687, 160, 1L, out intPtr);
			this.label26.ForeColor = Color.GreenYellow;
			this.label26.Text = "[Enabled]";
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00004034 File Offset: 0x00002234
		private void button24_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 3687, 32, 1L, out intPtr);
			this.label26.ForeColor = Color.Red;
			this.label26.Text = "[Disabled]";
		}

		// Token: 0x06000038 RID: 56 RVA: 0x0000212A File Offset: 0x0000032A
		private void button23_Click(object sender, EventArgs e)
		{
			this.p2ammo = true;
			this.label24.ForeColor = Color.GreenYellow;
			this.label24.Text = "[Enabled]";
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00002156 File Offset: 0x00000356
		private void button22_Click(object sender, EventArgs e)
		{
			this.p2ammo = false;
			this.label24.ForeColor = Color.Red;
			this.label24.Text = "[Disabled]";
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00004098 File Offset: 0x00002298
		private void button20_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < 4; i++)
			{
				IntPtr intPtr;
				cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 23828, this.numericUpDown2.Value, 4L, out intPtr);
			}
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00002182 File Offset: 0x00000382
		private void button21_Click(object sender, EventArgs e)
		{
			this.p2points = true;
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000040F4 File Offset: 0x000022F4
		private void button19_Click(object sender, EventArgs e)
		{
			long num = long.Parse(this.p2weaponid.Text);
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 47424 + 176, num, 8L, out intPtr);
		}

		// Token: 0x0600003D RID: 61 RVA: 0x0000205B File Offset: 0x0000025B
		private void Form1_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00004144 File Offset: 0x00002344
		private void button34_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 3687, 160, 1L, out intPtr);
			this.label34.ForeColor = Color.GreenYellow;
			this.label34.Text = "(Enabled)";
		}

		// Token: 0x0600003F RID: 63 RVA: 0x000041A8 File Offset: 0x000023A8
		private void button33_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 3687, 32, 1L, out intPtr);
			this.label34.ForeColor = Color.Red;
			this.label34.Text = "(Disabled)";
		}

		// Token: 0x06000040 RID: 64 RVA: 0x0000218C File Offset: 0x0000038C
		private void button32_Click(object sender, EventArgs e)
		{
			this.p3ammo = true;
			this.label32.ForeColor = Color.GreenYellow;
			this.label32.Text = "(Enabled)";
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000021B8 File Offset: 0x000003B8
		private void button31_Click(object sender, EventArgs e)
		{
			this.p3ammo = false;
			this.label32.ForeColor = Color.Red;
			this.label32.Text = "(Disabled)";
		}

		// Token: 0x06000042 RID: 66 RVA: 0x0000420C File Offset: 0x0000240C
		private void button29_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < 4; i++)
			{
				IntPtr intPtr;
				cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 23828, this.numericUpDown3.Value, 4L, out intPtr);
			}
		}

		// Token: 0x06000043 RID: 67 RVA: 0x000021E4 File Offset: 0x000003E4
		private void button30_Click(object sender, EventArgs e)
		{
			this.p3points = true;
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00004268 File Offset: 0x00002468
		private void button28_Click(object sender, EventArgs e)
		{
			long num = long.Parse(this.p3weaponid.Text);
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 94848 + 176, num, 8L, out intPtr);
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000042B8 File Offset: 0x000024B8
		private void button43_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 3687, 160, 1L, out intPtr);
			this.label42.ForeColor = Color.GreenYellow;
			this.label42.Text = "(Enabled)";
		}

		// Token: 0x06000046 RID: 70 RVA: 0x0000431C File Offset: 0x0000251C
		private void button42_Click(object sender, EventArgs e)
		{
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 3687, 32, 1L, out intPtr);
			this.label42.ForeColor = Color.Red;
			this.label42.Text = "(Disabled)";
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000021EE File Offset: 0x000003EE
		private void button41_Click(object sender, EventArgs e)
		{
			this.p4ammo = true;
			this.label40.ForeColor = Color.GreenYellow;
			this.label40.Text = "(Enabled)";
		}

		// Token: 0x06000048 RID: 72 RVA: 0x0000221A File Offset: 0x0000041A
		private void button40_Click(object sender, EventArgs e)
		{
			this.p4ammo = false;
			this.label40.ForeColor = Color.Red;
			this.label40.Text = "(Disabled)";
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00004380 File Offset: 0x00002580
		private void button38_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < 4; i++)
			{
				IntPtr intPtr;
				cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 23828, this.numericUpDown4.Value, 4L, out intPtr);
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00002246 File Offset: 0x00000446
		private void button39_Click(object sender, EventArgs e)
		{
			this.p4points = true;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x000043DC File Offset: 0x000025DC
		private void button37_Click(object sender, EventArgs e)
		{
			long num = long.Parse(this.p4weaponid.Text);
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, this.PlayerCompPtr + 142272 + 176, num, 8L, out intPtr);
		}

		// Token: 0x0600004C RID: 76 RVA: 0x0000206C File Offset: 0x0000026C
		private void button35_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Soon", "Basic Tuul Base", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0600004D RID: 77 RVA: 0x0000205B File Offset: 0x0000025B
		private void button26_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000206C File Offset: 0x0000026C
		private void button17_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Soon", "Basic Tuul Base", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00002250 File Offset: 0x00000450
		private void button18_Click(object sender, EventArgs e)
		{
			Process.Start("https://pastebin.com/Xf5E0XDM");
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00002250 File Offset: 0x00000450
		private void button36_Click(object sender, EventArgs e)
		{
			Process.Start("https://pastebin.com/Xf5E0XDM");
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00002250 File Offset: 0x00000450
		private void button27_Click(object sender, EventArgs e)
		{
			Process.Start("https://pastebin.com/Xf5E0XDM");
		}

		// Token: 0x06000052 RID: 82 RVA: 0x0000442C File Offset: 0x0000262C
		private void trackBar1_Scroll(object sender, EventArgs e)
		{
			this.label45.Text = this.trackBar1.Value.ToString() + "x";
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00004464 File Offset: 0x00002664
		private void trackBar2_Scroll(object sender, EventArgs e)
		{
			this.label46.Text = this.trackBar2.Value.ToString() + "x";
		}

		// Token: 0x06000054 RID: 84 RVA: 0x0000225E File Offset: 0x0000045E
		private void button48_Click(object sender, EventArgs e)
		{
			this.instakill = true;
			this.label48.ForeColor = Color.YellowGreen;
			this.label48.Text = "[Enabled]";
		}

		// Token: 0x06000055 RID: 85 RVA: 0x0000228A File Offset: 0x0000048A
		private void button47_Click(object sender, EventArgs e)
		{
			this.instakill = false;
			this.label48.ForeColor = Color.Red;
			this.label48.Text = "[Disabled]";
		}

		// Token: 0x06000056 RID: 86 RVA: 0x0000449C File Offset: 0x0000269C
		private void button46_Click(object sender, EventArgs e)
		{
			bool flag = !this.backgroundWorker1.IsBusy;
			bool flag2 = flag;
			if (flag2)
			{
				this.backgroundWorker1.RunWorkerAsync();
			}
			this.toolbaseon = !this.toolbaseon;
			bool flag3 = this.toolbaseon;
			bool flag4 = flag3;
			if (flag4)
			{
				this.label9.Text = "(On)";
				this.label9.ForeColor = Color.Green;
				this.button46.ForeColor = Color.Green;
				this.ConsoleOut("[Enabled]");
			}
			else
			{
				this.label9.Text = "(Off)";
				this.label9.ForeColor = Color.Red;
				this.button46.ForeColor = Color.Red;
				this.ConsoleOut("[Disabled]");
			}
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0000205B File Offset: 0x0000025B
		private void button7_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000058 RID: 88 RVA: 0x0000205B File Offset: 0x0000025B
		private void button51_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000205B File Offset: 0x0000025B
		private void button5_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000205B File Offset: 0x0000025B
		private void button54_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600005B RID: 91 RVA: 0x0000205B File Offset: 0x0000025B
		private void button52_Click_1(object sender, EventArgs e)
		{
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000022B6 File Offset: 0x000004B6
		private void button50_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Will be updated.", "HypeCheats VIP", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		// Token: 0x0600005D RID: 93 RVA: 0x0000205B File Offset: 0x0000025B
		private void button53_Click_1(object sender, EventArgs e)
		{
		}

		// Token: 0x0600005E RID: 94 RVA: 0x0000205B File Offset: 0x0000025B
		private void button6_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600005F RID: 95 RVA: 0x0000205B File Offset: 0x0000025B
		private void button49_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000060 RID: 96 RVA: 0x0000205B File Offset: 0x0000025B
		private void button56_Click_3(object sender, EventArgs e)
		{
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000205B File Offset: 0x0000025B
		private void button44_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000062 RID: 98 RVA: 0x000022CC File Offset: 0x000004CC
		private void button57_Click(object sender, EventArgs e)
		{
			this.timer1.Start();
		}

		// Token: 0x06000063 RID: 99 RVA: 0x0000456C File Offset: 0x0000276C
		private void button58_Click(object sender, EventArgs e)
		{
			this.timer1.Stop();
			this.tuulname.ForeColor = Color.DodgerBlue;
			this.label9.ForeColor = Color.Red;
			this.button1.ForeColor = Color.Red;
			this.groupBox1.ForeColor = Color.White;
			this.label11.ForeColor = Color.White;
		}

		// Token: 0x06000064 RID: 100 RVA: 0x000045DC File Offset: 0x000027DC
		private void timer1_Tick(object sender, EventArgs e)
		{
			Random random = new Random();
			int alpha = random.Next(0, 255);
			int red = random.Next(0, 255);
			int green = random.Next(0, 255);
			int blue = random.Next(0, 255);
			this.tuulname.ForeColor = Color.FromArgb(alpha, red, green, blue);
			this.label9.ForeColor = Color.FromArgb(alpha, red, green, blue);
			this.button1.ForeColor = Color.FromArgb(alpha, red, green, blue);
			this.groupBox1.ForeColor = Color.FromArgb(alpha, red, green, blue);
			this.label11.ForeColor = Color.FromArgb(alpha, red, green, blue);
		}

		// Token: 0x06000065 RID: 101 RVA: 0x0000205B File Offset: 0x0000025B
		private void trackBar3_Scroll(object sender, EventArgs e)
		{
		}

		// Token: 0x06000066 RID: 102 RVA: 0x000022DB File Offset: 0x000004DB
		private void Form1_Leave(object sender, EventArgs e)
		{
			this.timer2.Stop();
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00004694 File Offset: 0x00002894
		private void timer2_Tick(object sender, EventArgs e)
		{
			Random random = new Random();
			int alpha = random.Next(0, 255);
			int red = random.Next(0, 255);
			int green = random.Next(0, 255);
			int blue = random.Next(0, 255);
			this.label29.ForeColor = Color.FromArgb(alpha, red, green, blue);
		}

		// Token: 0x06000068 RID: 104 RVA: 0x000046F4 File Offset: 0x000028F4
		public void UpdateLabel(Label label, string text, string color = "Black")
		{
			bool invokeRequired = base.InvokeRequired;
			bool flag = invokeRequired;
			if (flag)
			{
				label.Invoke(new MethodInvoker(delegate()
				{
					label.Text = text;
					label.ForeColor = Color.FromName(color);
				}));
			}
			else
			{
				label.Text = text;
				label.ForeColor = Color.FromName(color);
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00004770 File Offset: 0x00002970
		public void ConsoleOut(string str)
		{
			bool invokeRequired = base.InvokeRequired;
			bool flag = invokeRequired;
			if (flag)
			{
				base.Invoke(new Action<string>(this.ConsoleOut), new object[]
				{
					str
				});
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x000047B0 File Offset: 0x000029B0
		public void SendCMD(string Command)
		{
			byte[] array = new byte[Command.Length];
			array = Encoding.UTF8.GetBytes(Command + "\0");
			IntPtr intPtr;
			cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.CMDBufferBase.ToInt64()), array, (long)array.Length, out intPtr);
			cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.CMDBufferBase.ToInt64()) - 27, 1, 1L, out intPtr);
			Thread.Sleep(20);
			cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.CMDBufferBase.ToInt64()) - 27, 0, 1L, out intPtr);
			array = Encoding.UTF8.GetBytes("\0");
			cwapi.WriteProcessMemory(this.hProc, (IntPtr)(this.baseAddress.ToInt64() + this.CMDBufferBase.ToInt64()), array, (long)array.Length, out intPtr);
		}

		// Token: 0x0600006B RID: 107 RVA: 0x000048C8 File Offset: 0x00002AC8
		public double ConvertToRadians(double angle)
		{
			return 0.017453292519943295 * angle;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x0000205B File Offset: 0x0000025B
		private void label42_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000205B File Offset: 0x0000025B
		private void label40_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600006E RID: 110 RVA: 0x0000205B File Offset: 0x0000025B
		private void groupBox4_Enter(object sender, EventArgs e)
		{
		}

		// Token: 0x0600006F RID: 111 RVA: 0x0000205B File Offset: 0x0000025B
		private void label25_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000070 RID: 112 RVA: 0x0000205B File Offset: 0x0000025B
		private void label24_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000205B File Offset: 0x0000025B
		private void label22_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000072 RID: 114 RVA: 0x0000205B File Offset: 0x0000025B
		private void player2_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000073 RID: 115 RVA: 0x0000205B File Offset: 0x0000025B
		private void checkBox3_CheckedChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000074 RID: 116 RVA: 0x0000205B File Offset: 0x0000025B
		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000075 RID: 117 RVA: 0x0000205B File Offset: 0x0000025B
		private void label9_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000076 RID: 118 RVA: 0x0000205B File Offset: 0x0000025B
		private void button60_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000077 RID: 119 RVA: 0x0000205B File Offset: 0x0000025B
		private void tuulname_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000078 RID: 120 RVA: 0x0000205B File Offset: 0x0000025B
		private void label14_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000079 RID: 121 RVA: 0x0000205B File Offset: 0x0000025B
		private void label34_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600007A RID: 122 RVA: 0x0000205B File Offset: 0x0000025B
		private void checkBox3_CheckedChanged_1(object sender, EventArgs e)
		{
		}

		// Token: 0x0400000A RID: 10

		// Token: 0x0400000B RID: 11
		public int gamePID = 0;

		// Token: 0x0400000C RID: 12
		public IntPtr hProc;

		// Token: 0x0400000D RID: 13
		public IntPtr baseAddress = IntPtr.Zero;

		// Token: 0x0400000E RID: 14
		public Color defaultColor = Color.Black;

		// Token: 0x0400000F RID: 15
		public bool toolbaseon = false;

		// Token: 0x04000010 RID: 16
		public bool p1ammo = false;

		// Token: 0x04000011 RID: 17
		public bool p2ammo = false;

		// Token: 0x04000012 RID: 18
		public bool p3ammo = false;

		// Token: 0x04000013 RID: 19
		public bool p4ammo = false;

		// Token: 0x04000014 RID: 20
		public bool p1points = false;

		// Token: 0x04000015 RID: 21
		public bool p2points = false;

		// Token: 0x04000016 RID: 22
		public bool p3points = false;

		// Token: 0x04000017 RID: 23
		public bool p4points = false;

		// Token: 0x04000018 RID: 24
		public bool instakill = false;

		// Token: 0x04000019 RID: 25
		public Process gameProc;

		// Token: 0x0400001A RID: 26
		public float playerSpeed = -1f;

		// Token: 0x0400001B RID: 27
		public bool ammoFrozen;

		// Token: 0x0400001C RID: 28
		public int[] ammoVals = new int[6];

		// Token: 0x0400001D RID: 29
		public int[] maxAmmoVals = new int[6];

		// Token: 0x0400001E RID: 30
		public Vector3 frozenPlayerPos = Vector3.Zero;

		// Token: 0x0400001F RID: 31
		public Vector3 lastKnownPlayerPos = Vector3.Zero;

		// Token: 0x04000020 RID: 32
		public Vector3 updatedPlayerPos = Vector3.Zero;

		// Token: 0x04000021 RID: 33
		public Vector3 zombieTpPos;

		// Token: 0x04000022 RID: 34
		public float TimesModifier = 1f;

		// Token: 0x04000023 RID: 35
		public byte tempCritKill;

		// Token: 0x04000024 RID: 36
		public int ZLeft = 0;

		// Token: 0x04000025 RID: 37
		public IntPtr PlayerBase = (IntPtr)272996624;

		// Token: 0x04000026 RID: 38
		public IntPtr CMDBufferBase = (IntPtr)298099120;

		// Token: 0x04000027 RID: 39
		public IntPtr XPScaleBase = (IntPtr)273160456;

		// Token: 0x04000028 RID: 40
		public IntPtr PlayerCompPtr;

		// Token: 0x04000029 RID: 41
		public IntPtr PlayerPedPtr;

		// Token: 0x0400002A RID: 42
		public IntPtr ZMGlobalBase;

		// Token: 0x0400002B RID: 43
		public IntPtr ZMBotBase;

		// Token: 0x0400002C RID: 44
		public IntPtr ZMBotListBase;

		// Token: 0x0400002D RID: 45
		public const int PlayerXP = 40;

		// Token: 0x0400002E RID: 46
		public const int PlayerXP2 = 48;

		// Token: 0x0400002F RID: 47
		public const int WeaponXP = 48;

		// Token: 0x04000030 RID: 48
		public const int client_size = 124342;

		// Token: 0x04000031 RID: 49
		public const int PC_ArraySize_Offset = 47424;

		// Token: 0x04000032 RID: 50
		public const int PC_CurrentUsedWeaponID = 40;

		// Token: 0x04000033 RID: 51
		public const int PC_SetWeaponID = 176;

		// Token: 0x04000034 RID: 52
		public const int PC_InfraredVision = 3686;

		// Token: 0x04000035 RID: 53
		public const int PC_GodMode = 3687;

		// Token: 0x04000036 RID: 54
		public const int PC_RapidFire1 = 3692;

		// Token: 0x04000037 RID: 55
		public const int PC_RapidFire2 = 3712;

		// Token: 0x04000038 RID: 56
		public const int PC_MaxAmmo = 4960;

		// Token: 0x04000039 RID: 57
		public const int PC_Ammo = 5076;

		// Token: 0x0400003A RID: 58
		public const int PC_Points = 23828;

		// Token: 0x0400003B RID: 59
		public const int PC_Name = 23562;

		// Token: 0x0400003C RID: 60
		public const int PC_RunSpeed = 23648;

		// Token: 0x0400003D RID: 61
		public const int PC_ClanTags = 24668;

		// Token: 0x0400003E RID: 62
		public const int PC_autoFire = 3696;

		// Token: 0x0400003F RID: 63
		public const int PC_Coords = 3560;

		// Token: 0x04000040 RID: 64
		public const int KillCount = 23784;

		// Token: 0x04000041 RID: 65
		public const int CritKill8 = 4316;

		// Token: 0x04000042 RID: 66
		public const int PP_ArraySize_Offset = 1528;

		// Token: 0x04000043 RID: 67
		public const int PP_Health = 920;

		// Token: 0x04000044 RID: 68
		public const int PP_MaxHealth = 924;

		// Token: 0x04000045 RID: 69
		public const int PP_Coords = 724;

		// Token: 0x04000046 RID: 70
		public const int PP_Heading_Z = 52;

		// Token: 0x04000047 RID: 71
		public const int PP_Heading_XY = 56;

		// Token: 0x04000048 RID: 72
		public const int ZM_Global_MovedOffset = 0;

		// Token: 0x04000049 RID: 73
		public const int ZM_Global_ZombiesIgnoreAll = 20;

		// Token: 0x0400004A RID: 74
		public const int ZM_Bot_List_Offset = 8;

		// Token: 0x0400004B RID: 75
		public const int ZM_Bot_ArraySize_Offset = 1528;

		// Token: 0x0400004C RID: 76
		public const int ZM_Bot_Health = 920;

		// Token: 0x0400004D RID: 77
		public const int ZM_Bot_MaxHealth = 924;

		// Token: 0x0400004E RID: 78
		public const int ZM_Bot_Coords = 724;

		// Token: 0x0400004F RID: 79
		private bool mouseDown;

		// Token: 0x04000050 RID: 80
		private Point offset;
	}
}
