﻿namespace CWTuulBase
{
	// Token: 0x02000005 RID: 5
	public partial class Form2 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000087 RID: 135 RVA: 0x0000A428 File Offset: 0x00008628
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			bool flag2 = flag;
			if (flag2)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x0000A464 File Offset: 0x00008664
		private void InitializeComponent()
		{
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.button1 = new global::System.Windows.Forms.Button();
			this.label36 = new global::System.Windows.Forms.Label();
			this.Username = new global::System.Windows.Forms.TextBox();
			this.button2 = new global::System.Windows.Forms.Button();
			this.label1 = new global::System.Windows.Forms.Label();
			this.toolname = new global::System.Windows.Forms.TextBox();
			this.panel1.SuspendLayout();
			base.SuspendLayout();
			this.panel1.Controls.Add(this.button1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(187, 56);
			this.panel1.TabIndex = 0;
			this.panel1.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.MouseDown_Event);
			this.panel1.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.MouseMove_Event);
			this.panel1.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.MouseUp_Event);
			this.button1.BackColor = global::System.Drawing.Color.Transparent;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button1.ForeColor = global::System.Drawing.Color.Red;
			this.button1.Location = new global::System.Drawing.Point(153, 3);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(31, 30);
			this.button1.TabIndex = 1;
			this.button1.Text = "X";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.label36.AutoSize = true;
			this.label36.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label36.ForeColor = global::System.Drawing.Color.White;
			this.label36.Location = new global::System.Drawing.Point(9, 43);
			this.label36.Name = "label36";
			this.label36.Size = new global::System.Drawing.Size(87, 16);
			this.label36.TabIndex = 76;
			this.label36.Text = "Username:";
			this.Username.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Username.Location = new global::System.Drawing.Point(12, 62);
			this.Username.Name = "Username";
			this.Username.Size = new global::System.Drawing.Size(163, 23);
			this.Username.TabIndex = 75;
			this.Username.TextChanged += new global::System.EventHandler(this.Username_TextChanged);
			this.button2.BackColor = global::System.Drawing.Color.Transparent;
			this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button2.ForeColor = global::System.Drawing.Color.RoyalBlue;
			this.button2.Location = new global::System.Drawing.Point(12, 138);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(163, 34);
			this.button2.TabIndex = 2;
			this.button2.Text = "Load Tool";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.Color.White;
			this.label1.Location = new global::System.Drawing.Point(9, 90);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(89, 16);
			this.label1.TabIndex = 78;
			this.label1.Text = "Tool Name:";
			this.toolname.Font = new global::System.Drawing.Font("Verdana", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.toolname.Location = new global::System.Drawing.Point(12, 109);
			this.toolname.Name = "toolname";
			this.toolname.Size = new global::System.Drawing.Size(163, 23);
			this.toolname.TabIndex = 77;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.SystemColors.InfoText;
			base.ClientSize = new global::System.Drawing.Size(187, 183);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.toolname);
			base.Controls.Add(this.button2);
			base.Controls.Add(this.label36);
			base.Controls.Add(this.Username);
			base.Controls.Add(this.panel1);
			this.Cursor = global::System.Windows.Forms.Cursors.Cross;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Form2";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form2";
			base.Load += new global::System.EventHandler(this.Form2_Load);
			this.panel1.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040000C4 RID: 196
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x040000C5 RID: 197
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x040000C6 RID: 198
		private global::System.Windows.Forms.Button button1;

		// Token: 0x040000C7 RID: 199
		private global::System.Windows.Forms.Label label36;

		// Token: 0x040000C8 RID: 200
		private global::System.Windows.Forms.TextBox Username;

		// Token: 0x040000C9 RID: 201
		private global::System.Windows.Forms.Button button2;

		// Token: 0x040000CA RID: 202
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000CB RID: 203
		private global::System.Windows.Forms.TextBox toolname;
	}
}
